-- phpMyAdmin SQL Dump
-- version 4.6.6deb5ubuntu0.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 06, 2021 at 06:56 PM
-- Server version: 5.7.35-0ubuntu0.18.04.2
-- PHP Version: 7.2.24-0ubuntu0.18.04.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `krmmn`
--

-- --------------------------------------------------------

--
-- Table structure for table `academic_year`
--

CREATE TABLE `academic_year` (
  `academic_year_id` int(11) NOT NULL,
  `start_year` decimal(4,0) NOT NULL,
  `end_year` decimal(4,0) NOT NULL,
  `current_year` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(10) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(10) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `on_update` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `academic_year`
--

INSERT INTO `academic_year` (`academic_year_id`, `start_year`, `end_year`, `current_year`, `is_active`, `is_deleted`, `created_on`, `on_update`) VALUES
(1, '2021', '2022', 1, 1, 0, '2021-04-27 03:18:31', '2021-04-27 17:18:43'),
(2, '2022', '2023', 0, 1, 0, '2021-09-23 02:58:17', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(2) NOT NULL,
  `admin_name` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(2000) NOT NULL,
  `timestamp` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `admin_profile` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `email`, `password`, `timestamp`, `admin_profile`) VALUES
(1, 'Dr. Vijaya Deshmukh', 'admin@krmmn.in', '$2y$10$wU383z.dB4onx8r8zQPsDObMm.ks58xFpt0NBBPINiIR9pmzMWXe2', '2020-11-23 18:30:00.000000', '1631960989.png');

-- --------------------------------------------------------

--
-- Table structure for table `bonafied_certificate`
--

CREATE TABLE `bonafied_certificate` (
  `bonafied_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `bonafied_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `bonafied_reason` varchar(200) NOT NULL,
  `approved_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `branches_id` int(11) NOT NULL,
  `branch_name` varchar(102) DEFAULT NULL,
  `short_name` varchar(20) NOT NULL,
  `course_id` int(11) NOT NULL,
  `head_of_department` int(11) DEFAULT NULL,
  `is_active` tinyint(10) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(10) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `on_update` timestamp NULL DEFAULT NULL,
  `staffs` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`branches_id`, `branch_name`, `short_name`, `course_id`, `head_of_department`, `is_active`, `is_deleted`, `created_on`, `on_update`, `staffs`) VALUES
(1, 'Bachelor of Arts', 'B.A', 1, 28, 1, 0, '2021-03-08 13:02:55', '2021-05-19 15:55:00', NULL),
(2, 'Bachelor of Science', 'B.Sc', 1, 29, 1, 0, '2021-03-08 13:03:50', '2021-05-19 15:55:04', NULL),
(3, 'Bachelor of Commerce', 'B.Com', 1, 16, 1, 0, '2021-03-08 13:04:18', '2021-05-17 18:37:40', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `branch_and_year`
--

CREATE TABLE `branch_and_year` (
  `branch_and_year_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `year_id` int(11) NOT NULL,
  `is_active` tinyint(10) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(10) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `on_update` timestamp NULL DEFAULT NULL,
  `fees_details` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch_and_year`
--

INSERT INTO `branch_and_year` (`branch_and_year_id`, `branch_id`, `year_id`, `is_active`, `is_deleted`, `created_on`, `on_update`, `fees_details`) VALUES
(1, 1, 1, 1, 0, '2021-09-18 13:10:58', NULL, '[{\"academic_year_id\":\"1\",\"fees_header\":[{\"fees_amount\":\"10\",\"header\":\"Registration Fees\",\"header_id\":\"1\"},{\"fees_amount\":\"40\",\"header\":\"Admission Fees\",\"header_id\":\"2\"},{\"fees_amount\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\"},{\"fees_amount\":\"150\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\"},{\"fees_amount\":\"60\",\"header\":\"Magazine Fees\",\"header_id\":\"5\"},{\"fees_amount\":\"10\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\"},{\"fees_amount\":\"50\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\"},{\"fees_amount\":\"60\",\"header\":\"Gathering Fees\",\"header_id\":\"8\"},{\"fees_amount\":\"150\",\"header\":\"Library Fees\",\"header_id\":\"9\"},{\"fees_amount\":\"60\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\"},{\"fees_amount\":\"50\",\"header\":\"College Development Fees\",\"header_id\":\"11\"},{\"fees_amount\":\"10\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\"},{\"fees_amount\":\"15\",\"header\":\"Student Forum fees\",\"header_id\":\"13\"},{\"fees_amount\":\"30\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\"},{\"fees_amount\":\"5\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\"},{\"fees_amount\":\"0\",\"header\":\"Project Fees\",\"header_id\":\"16\"},{\"fees_amount\":\"50\",\"header\":\"University Sports Fees\",\"header_id\":\"17\"},{\"fees_amount\":\"20\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\"},{\"fees_amount\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\"},{\"fees_amount\":\"10\",\"header\":\"Book Bank\",\"header_id\":\"20\"},{\"fees_amount\":\"50\",\"header\":\"Youth Festival\",\"header_id\":\"21\"},{\"fees_amount\":\"30\",\"header\":\"Ashwamedh\",\"header_id\":\"22\"},{\"fees_amount\":\"15\",\"header\":\"Emergency Fees\",\"header_id\":\"23\"},{\"fees_amount\":\"8\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\"},{\"fees_amount\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\"},{\"fees_amount\":\"110\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\"},{\"fees_amount\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\"},{\"fees_amount\":\"1000\",\"header\":\"Tution Fees\",\"header_id\":\"31\"},{\"fees_amount\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\"},{\"fees_amount\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\"},{\"fees_amount\":\"0\",\"header\":\"Environment Sci\",\"header_id\":\"34\"},{\"fees_amount\":\"0\",\"header\":\"Proirianal Passing Certficate Fees\",\"header_id\":\"35\"},{\"fees_amount\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\"},{\"fees_amount\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\"},{\"fees_amount\":\"32\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\"},{\"fees_amount\":\"50\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\"}]},{\"academic_year_id\":\"2\",\"fees_header\":[{\"fees_amount\":\"200\",\"header\":\"Registration Fees\",\"header_id\":\"1\"},{\"fees_amount\":\"0\",\"header\":\"Admission Fees\",\"header_id\":\"2\"},{\"fees_amount\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\"},{\"fees_amount\":\"0\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\"},{\"fees_amount\":\"0\",\"header\":\"Magazine Fees\",\"header_id\":\"5\"},{\"fees_amount\":\"0\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\"},{\"fees_amount\":\"0\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\"},{\"fees_amount\":\"0\",\"header\":\"Gathering Fees\",\"header_id\":\"8\"},{\"fees_amount\":\"0\",\"header\":\"Library Fees\",\"header_id\":\"9\"},{\"fees_amount\":\"0\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\"},{\"fees_amount\":\"0\",\"header\":\"College Development Fees\",\"header_id\":\"11\"},{\"fees_amount\":\"0\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\"},{\"fees_amount\":\"0\",\"header\":\"Student Forum fees\",\"header_id\":\"13\"},{\"fees_amount\":\"0\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\"},{\"fees_amount\":\"0\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\"},{\"fees_amount\":\"0\",\"header\":\"Project Fees\",\"header_id\":\"16\"},{\"fees_amount\":\"0\",\"header\":\"University Sports Fees\",\"header_id\":\"17\"},{\"fees_amount\":\"0\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\"},{\"fees_amount\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\"},{\"fees_amount\":\"0\",\"header\":\"Book Bank\",\"header_id\":\"20\"},{\"fees_amount\":\"0\",\"header\":\"Youth Festival\",\"header_id\":\"21\"},{\"fees_amount\":\"0\",\"header\":\"Ashwamedh\",\"header_id\":\"22\"},{\"fees_amount\":\"0\",\"header\":\"Emergency Fees\",\"header_id\":\"23\"},{\"fees_amount\":\"0\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\"},{\"fees_amount\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\"},{\"fees_amount\":\"0\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\"},{\"fees_amount\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\"},{\"fees_amount\":\"0\",\"header\":\"Tution Fees\",\"header_id\":\"31\"},{\"fees_amount\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\"},{\"fees_amount\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\"},{\"fees_amount\":\"0\",\"header\":\"Environment Sci\",\"header_id\":\"34\"},{\"fees_amount\":\"0\",\"header\":\"Proirianal Passing Certficate Fees\",\"header_id\":\"35\"},{\"fees_amount\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\"},{\"fees_amount\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\"},{\"fees_amount\":\"0\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\"},{\"fees_amount\":\"0\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\"}]}]'),
(2, 1, 2, 1, 0, '2021-09-18 13:11:10', NULL, '[{\"academic_year_id\":\"1\",\"fees_header\":[{\"fees_amount\":\"10\",\"header\":\"Registration Fees\",\"header_id\":\"1\"},{\"fees_amount\":\"40\",\"header\":\"Admission Fees\",\"header_id\":\"2\"},{\"fees_amount\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\"},{\"fees_amount\":\"150\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\"},{\"fees_amount\":\"60\",\"header\":\"Magazine Fees\",\"header_id\":\"5\"},{\"fees_amount\":\"10\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\"},{\"fees_amount\":\"50\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\"},{\"fees_amount\":\"60\",\"header\":\"Gathering Fees\",\"header_id\":\"8\"},{\"fees_amount\":\"150\",\"header\":\"Library Fees\",\"header_id\":\"9\"},{\"fees_amount\":\"60\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\"},{\"fees_amount\":\"50\",\"header\":\"College Development Fees\",\"header_id\":\"11\"},{\"fees_amount\":\"10\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\"},{\"fees_amount\":\"15\",\"header\":\"Student Forum fees\",\"header_id\":\"13\"},{\"fees_amount\":\"30\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\"},{\"fees_amount\":\"5\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\"},{\"fees_amount\":\"0\",\"header\":\"Project Fees\",\"header_id\":\"16\"},{\"fees_amount\":\"50\",\"header\":\"University Sports Fees\",\"header_id\":\"17\"},{\"fees_amount\":\"20\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\"},{\"fees_amount\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\"},{\"fees_amount\":\"10\",\"header\":\"Book Bank\",\"header_id\":\"20\"},{\"fees_amount\":\"50\",\"header\":\"Youth Festival\",\"header_id\":\"21\"},{\"fees_amount\":\"30\",\"header\":\"Ashwamedh\",\"header_id\":\"22\"},{\"fees_amount\":\"15\",\"header\":\"Emergency Fees\",\"header_id\":\"23\"},{\"fees_amount\":\"8\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\"},{\"fees_amount\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\"},{\"fees_amount\":\"0\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\"},{\"fees_amount\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\"},{\"fees_amount\":\"1000\",\"header\":\"Tution Fees\",\"header_id\":\"31\"},{\"fees_amount\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\"},{\"fees_amount\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\"},{\"fees_amount\":\"0\",\"header\":\"Environment Studies Fees\",\"header_id\":\"34\"},{\"fees_amount\":\"0\",\"header\":\"Provisional Passing Certficate Fees\",\"header_id\":\"35\"},{\"fees_amount\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\"},{\"fees_amount\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\"},{\"fees_amount\":\"32\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\"},{\"fees_amount\":\"50\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\"}]}]'),
(3, 1, 3, 1, 0, '2021-09-18 13:11:20', NULL, '[{\"academic_year_id\":\"1\",\"fees_header\":[{\"fees_amount\":\"10\",\"header\":\"Registration Fees\",\"header_id\":\"1\"},{\"fees_amount\":\"40\",\"header\":\"Admission Fees\",\"header_id\":\"2\"},{\"fees_amount\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\"},{\"fees_amount\":\"150\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\"},{\"fees_amount\":\"60\",\"header\":\"Magazine Fees\",\"header_id\":\"5\"},{\"fees_amount\":\"10\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\"},{\"fees_amount\":\"50\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\"},{\"fees_amount\":\"60\",\"header\":\"Gathering Fees\",\"header_id\":\"8\"},{\"fees_amount\":\"150\",\"header\":\"Library Fees\",\"header_id\":\"9\"},{\"fees_amount\":\"60\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\"},{\"fees_amount\":\"50\",\"header\":\"College Development Fees\",\"header_id\":\"11\"},{\"fees_amount\":\"10\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\"},{\"fees_amount\":\"15\",\"header\":\"Student Forum fees\",\"header_id\":\"13\"},{\"fees_amount\":\"30\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\"},{\"fees_amount\":\"5\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\"},{\"fees_amount\":\"0\",\"header\":\"Project Fees\",\"header_id\":\"16\"},{\"fees_amount\":\"50\",\"header\":\"University Sports Fees\",\"header_id\":\"17\"},{\"fees_amount\":\"20\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\"},{\"fees_amount\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\"},{\"fees_amount\":\"10\",\"header\":\"Book Bank\",\"header_id\":\"20\"},{\"fees_amount\":\"50\",\"header\":\"Youth Festival\",\"header_id\":\"21\"},{\"fees_amount\":\"30\",\"header\":\"Ashwamedh\",\"header_id\":\"22\"},{\"fees_amount\":\"15\",\"header\":\"Emergency Fees\",\"header_id\":\"23\"},{\"fees_amount\":\"8\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\"},{\"fees_amount\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\"},{\"fees_amount\":\"0\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\"},{\"fees_amount\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\"},{\"fees_amount\":\"1000\",\"header\":\"Tution Fees\",\"header_id\":\"31\"},{\"fees_amount\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\"},{\"fees_amount\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\"},{\"fees_amount\":\"150\",\"header\":\"Environment Studies Fees\",\"header_id\":\"34\"},{\"fees_amount\":\"75\",\"header\":\"Provisional Passing Certficate Fees\",\"header_id\":\"35\"},{\"fees_amount\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\"},{\"fees_amount\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\"},{\"fees_amount\":\"32\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\"},{\"fees_amount\":\"50\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\"}]}]'),
(4, 2, 1, 1, 0, '2021-09-18 13:11:28', NULL, '[{\"academic_year_id\":\"1\",\"fees_header\":[{\"fees_amount\":\"10\",\"header\":\"Registration Fees\",\"header_id\":\"1\"},{\"fees_amount\":\"40\",\"header\":\"Admission Fees\",\"header_id\":\"2\"},{\"fees_amount\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\"},{\"fees_amount\":\"0\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\"},{\"fees_amount\":\"60\",\"header\":\"Magazine Fees\",\"header_id\":\"5\"},{\"fees_amount\":\"10\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\"},{\"fees_amount\":\"50\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\"},{\"fees_amount\":\"60\",\"header\":\"Gathering Fees\",\"header_id\":\"8\"},{\"fees_amount\":\"150\",\"header\":\"Library Fees\",\"header_id\":\"9\"},{\"fees_amount\":\"60\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\"},{\"fees_amount\":\"50\",\"header\":\"College Development Fees\",\"header_id\":\"11\"},{\"fees_amount\":\"10\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\"},{\"fees_amount\":\"15\",\"header\":\"Student Forum fees\",\"header_id\":\"13\"},{\"fees_amount\":\"30\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\"},{\"fees_amount\":\"5\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\"},{\"fees_amount\":\"0\",\"header\":\"Project Fees\",\"header_id\":\"16\"},{\"fees_amount\":\"50\",\"header\":\"University Sports Fees\",\"header_id\":\"17\"},{\"fees_amount\":\"20\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\"},{\"fees_amount\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\"},{\"fees_amount\":\"10\",\"header\":\"Book Bank\",\"header_id\":\"20\"},{\"fees_amount\":\"50\",\"header\":\"Youth Festival\",\"header_id\":\"21\"},{\"fees_amount\":\"30\",\"header\":\"Ashwamedh\",\"header_id\":\"22\"},{\"fees_amount\":\"15\",\"header\":\"Emergency Fees\",\"header_id\":\"23\"},{\"fees_amount\":\"8\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\"},{\"fees_amount\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\"},{\"fees_amount\":\"110\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\"},{\"fees_amount\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\"},{\"fees_amount\":\"4000\",\"header\":\"Tution Fees\",\"header_id\":\"31\"},{\"fees_amount\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\"},{\"fees_amount\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\"},{\"fees_amount\":\"0\",\"header\":\"Environment Sci\",\"header_id\":\"34\"},{\"fees_amount\":\"0\",\"header\":\"Proirianal Passing Certficate Fees\",\"header_id\":\"35\"},{\"fees_amount\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\"},{\"fees_amount\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\"},{\"fees_amount\":\"32\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\"},{\"fees_amount\":\"50\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\"}]}]'),
(5, 2, 2, 1, 0, '2021-09-18 13:11:35', NULL, '[{\"academic_year_id\":\"1\",\"fees_header\":[{\"fees_amount\":\"10\",\"header\":\"Registration Fees\",\"header_id\":\"1\"},{\"fees_amount\":\"40\",\"header\":\"Admission Fees\",\"header_id\":\"2\"},{\"fees_amount\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\"},{\"fees_amount\":\"300\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\"},{\"fees_amount\":\"60\",\"header\":\"Magazine Fees\",\"header_id\":\"5\"},{\"fees_amount\":\"10\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\"},{\"fees_amount\":\"50\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\"},{\"fees_amount\":\"60\",\"header\":\"Gathering Fees\",\"header_id\":\"8\"},{\"fees_amount\":\"150\",\"header\":\"Library Fees\",\"header_id\":\"9\"},{\"fees_amount\":\"60\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\"},{\"fees_amount\":\"50\",\"header\":\"College Development Fees\",\"header_id\":\"11\"},{\"fees_amount\":\"10\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\"},{\"fees_amount\":\"15\",\"header\":\"Student Forum fees\",\"header_id\":\"13\"},{\"fees_amount\":\"30\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\"},{\"fees_amount\":\"5\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\"},{\"fees_amount\":\"0\",\"header\":\"Project Fees\",\"header_id\":\"16\"},{\"fees_amount\":\"50\",\"header\":\"University Sports Fees\",\"header_id\":\"17\"},{\"fees_amount\":\"20\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\"},{\"fees_amount\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\"},{\"fees_amount\":\"10\",\"header\":\"Book Bank\",\"header_id\":\"20\"},{\"fees_amount\":\"50\",\"header\":\"Youth Festival\",\"header_id\":\"21\"},{\"fees_amount\":\"30\",\"header\":\"Ashwamedh\",\"header_id\":\"22\"},{\"fees_amount\":\"15\",\"header\":\"Emergency Fees\",\"header_id\":\"23\"},{\"fees_amount\":\"8\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\"},{\"fees_amount\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\"},{\"fees_amount\":\"0\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\"},{\"fees_amount\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\"},{\"fees_amount\":\"4000\",\"header\":\"Tution Fees\",\"header_id\":\"31\"},{\"fees_amount\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\"},{\"fees_amount\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\"},{\"fees_amount\":\"0\",\"header\":\"Environment Sci\",\"header_id\":\"34\"},{\"fees_amount\":\"0\",\"header\":\"Proirianal Passing Certficate Fees\",\"header_id\":\"35\"},{\"fees_amount\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\"},{\"fees_amount\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\"},{\"fees_amount\":\"32\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\"},{\"fees_amount\":\"50\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\"}]}]'),
(6, 2, 3, 1, 0, '2021-09-18 13:11:41', NULL, '[{\"academic_year_id\":\"1\",\"fees_header\":[{\"fees_amount\":\"10\",\"header\":\"Registration Fees\",\"header_id\":\"1\"},{\"fees_amount\":\"40\",\"header\":\"Admission Fees\",\"header_id\":\"2\"},{\"fees_amount\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\"},{\"fees_amount\":\"300\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\"},{\"fees_amount\":\"60\",\"header\":\"Magazine Fees\",\"header_id\":\"5\"},{\"fees_amount\":\"10\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\"},{\"fees_amount\":\"50\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\"},{\"fees_amount\":\"60\",\"header\":\"Gathering Fees\",\"header_id\":\"8\"},{\"fees_amount\":\"150\",\"header\":\"Library Fees\",\"header_id\":\"9\"},{\"fees_amount\":\"60\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\"},{\"fees_amount\":\"50\",\"header\":\"College Development Fees\",\"header_id\":\"11\"},{\"fees_amount\":\"10\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\"},{\"fees_amount\":\"15\",\"header\":\"Student Forum fees\",\"header_id\":\"13\"},{\"fees_amount\":\"30\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\"},{\"fees_amount\":\"5\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\"},{\"fees_amount\":\"30\",\"header\":\"Project Fees\",\"header_id\":\"16\"},{\"fees_amount\":\"50\",\"header\":\"University Sports Fees\",\"header_id\":\"17\"},{\"fees_amount\":\"20\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\"},{\"fees_amount\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\"},{\"fees_amount\":\"10\",\"header\":\"Book Bank\",\"header_id\":\"20\"},{\"fees_amount\":\"50\",\"header\":\"Youth Festival\",\"header_id\":\"21\"},{\"fees_amount\":\"30\",\"header\":\"Ashwamedh\",\"header_id\":\"22\"},{\"fees_amount\":\"15\",\"header\":\"Emergency Fees\",\"header_id\":\"23\"},{\"fees_amount\":\"8\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\"},{\"fees_amount\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\"},{\"fees_amount\":\"\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\"},{\"fees_amount\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\"},{\"fees_amount\":\"4000\",\"header\":\"Tution Fees\",\"header_id\":\"31\"},{\"fees_amount\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\"},{\"fees_amount\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\"},{\"fees_amount\":\"150\",\"header\":\"Environment Sci\",\"header_id\":\"34\"},{\"fees_amount\":\"75\",\"header\":\"Proirianal Passing Certficate Fees\",\"header_id\":\"35\"},{\"fees_amount\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\"},{\"fees_amount\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\"},{\"fees_amount\":\"32\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\"},{\"fees_amount\":\"50\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\"}]}]'),
(7, 3, 1, 1, 0, '2021-09-18 13:11:48', NULL, '[{\"academic_year_id\":\"1\",\"fees_header\":[{\"fees_amount\":\"0\",\"header\":\"Registration Fees\",\"header_id\":\"1\"},{\"fees_amount\":\"0\",\"header\":\"Admission Fees\",\"header_id\":\"2\"},{\"fees_amount\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\"},{\"fees_amount\":\"0\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\"},{\"fees_amount\":\"0\",\"header\":\"Magazine Fees\",\"header_id\":\"5\"},{\"fees_amount\":\"0\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\"},{\"fees_amount\":\"0\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\"},{\"fees_amount\":\"0\",\"header\":\"Gathering Fees\",\"header_id\":\"8\"},{\"fees_amount\":\"0\",\"header\":\"Library Fees\",\"header_id\":\"9\"},{\"fees_amount\":\"0\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\"},{\"fees_amount\":\"0\",\"header\":\"College Development Fees\",\"header_id\":\"11\"},{\"fees_amount\":\"0\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\"},{\"fees_amount\":\"0\",\"header\":\"Student Forum fees\",\"header_id\":\"13\"},{\"fees_amount\":\"0\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\"},{\"fees_amount\":\"0\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\"},{\"fees_amount\":\"0\",\"header\":\"Project Fees\",\"header_id\":\"16\"},{\"fees_amount\":\"0\",\"header\":\"University Sports Fees\",\"header_id\":\"17\"},{\"fees_amount\":\"0\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\"},{\"fees_amount\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\"},{\"fees_amount\":\"0\",\"header\":\"Book Bank\",\"header_id\":\"20\"},{\"fees_amount\":\"0\",\"header\":\"Youth Festival\",\"header_id\":\"21\"},{\"fees_amount\":\"0\",\"header\":\"Ashwamedh\",\"header_id\":\"22\"},{\"fees_amount\":\"0\",\"header\":\"Emergency Fees\",\"header_id\":\"23\"},{\"fees_amount\":\"0\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\"},{\"fees_amount\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\"},{\"fees_amount\":\"0\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\"},{\"fees_amount\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\"},{\"fees_amount\":\"0\",\"header\":\"Tution Fees\",\"header_id\":\"31\"},{\"fees_amount\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\"},{\"fees_amount\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\"},{\"fees_amount\":\"0\",\"header\":\"Environment Studies Fees\",\"header_id\":\"34\"},{\"fees_amount\":\"0\",\"header\":\"Provisional Passing Certficate Fees\",\"header_id\":\"35\"},{\"fees_amount\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\"},{\"fees_amount\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\"},{\"fees_amount\":\"0\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\"},{\"fees_amount\":\"0\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\"}]}]'),
(8, 3, 2, 1, 0, '2021-09-18 13:11:57', NULL, '[{\"academic_year_id\":\"1\",\"fees_header\":[{\"fees_amount\":\"10\",\"header\":\"Registration Fees\",\"header_id\":\"1\"},{\"fees_amount\":\"40\",\"header\":\"Admission Fees\",\"header_id\":\"2\"},{\"fees_amount\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\"},{\"fees_amount\":\"0\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\"},{\"fees_amount\":\"60\",\"header\":\"Magazine Fees\",\"header_id\":\"5\"},{\"fees_amount\":\"10\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\"},{\"fees_amount\":\"50\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\"},{\"fees_amount\":\"60\",\"header\":\"Gathering Fees\",\"header_id\":\"8\"},{\"fees_amount\":\"150\",\"header\":\"Library Fees\",\"header_id\":\"9\"},{\"fees_amount\":\"60\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\"},{\"fees_amount\":\"50\",\"header\":\"College Development Fees\",\"header_id\":\"11\"},{\"fees_amount\":\"10\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\"},{\"fees_amount\":\"15\",\"header\":\"Student Forum fees\",\"header_id\":\"13\"},{\"fees_amount\":\"30\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\"},{\"fees_amount\":\"5\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\"},{\"fees_amount\":\"0\",\"header\":\"Project Fees\",\"header_id\":\"16\"},{\"fees_amount\":\"50\",\"header\":\"University Sports Fees\",\"header_id\":\"17\"},{\"fees_amount\":\"20\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\"},{\"fees_amount\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\"},{\"fees_amount\":\"10\",\"header\":\"Book Bank\",\"header_id\":\"20\"},{\"fees_amount\":\"50\",\"header\":\"Youth Festival\",\"header_id\":\"21\"},{\"fees_amount\":\"30\",\"header\":\"Ashwamedh\",\"header_id\":\"22\"},{\"fees_amount\":\"15\",\"header\":\"Emergency Fees\",\"header_id\":\"23\"},{\"fees_amount\":\"8\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\"},{\"fees_amount\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\"},{\"fees_amount\":\"0\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\"},{\"fees_amount\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\"},{\"fees_amount\":\"1000\",\"header\":\"Tution Fees\",\"header_id\":\"31\"},{\"fees_amount\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\"},{\"fees_amount\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\"},{\"fees_amount\":\"0\",\"header\":\"Environment Studies Fees\",\"header_id\":\"34\"},{\"fees_amount\":\"0\",\"header\":\"Provisional Passing Certficate Fees\",\"header_id\":\"35\"},{\"fees_amount\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\"},{\"fees_amount\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\"},{\"fees_amount\":\"32\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\"},{\"fees_amount\":\"50\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\"}]}]'),
(9, 3, 3, 1, 0, '2021-09-18 13:12:00', NULL, '[{\"academic_year_id\":\"1\",\"fees_header\":[{\"fees_amount\":\"10\",\"header\":\"Registration Fees\",\"header_id\":\"1\"},{\"fees_amount\":\"40\",\"header\":\"Admission Fees\",\"header_id\":\"2\"},{\"fees_amount\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\"},{\"fees_amount\":\"0\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\"},{\"fees_amount\":\"60\",\"header\":\"Magazine Fees\",\"header_id\":\"5\"},{\"fees_amount\":\"10\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\"},{\"fees_amount\":\"50\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\"},{\"fees_amount\":\"60\",\"header\":\"Gathering Fees\",\"header_id\":\"8\"},{\"fees_amount\":\"150\",\"header\":\"Library Fees\",\"header_id\":\"9\"},{\"fees_amount\":\"60\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\"},{\"fees_amount\":\"50\",\"header\":\"College Development Fees\",\"header_id\":\"11\"},{\"fees_amount\":\"10\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\"},{\"fees_amount\":\"15\",\"header\":\"Student Forum fees\",\"header_id\":\"13\"},{\"fees_amount\":\"30\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\"},{\"fees_amount\":\"5\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\"},{\"fees_amount\":\"30\",\"header\":\"Project Fees\",\"header_id\":\"16\"},{\"fees_amount\":\"50\",\"header\":\"University Sports Fees\",\"header_id\":\"17\"},{\"fees_amount\":\"20\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\"},{\"fees_amount\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\"},{\"fees_amount\":\"10\",\"header\":\"Book Bank\",\"header_id\":\"20\"},{\"fees_amount\":\"50\",\"header\":\"Youth Festival\",\"header_id\":\"21\"},{\"fees_amount\":\"30\",\"header\":\"Ashwamedh\",\"header_id\":\"22\"},{\"fees_amount\":\"15\",\"header\":\"Emergency Fees\",\"header_id\":\"23\"},{\"fees_amount\":\"8\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\"},{\"fees_amount\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\"},{\"fees_amount\":\"0\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\"},{\"fees_amount\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\"},{\"fees_amount\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\"},{\"fees_amount\":\"1000\",\"header\":\"Tution Fees\",\"header_id\":\"31\"},{\"fees_amount\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\"},{\"fees_amount\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\"},{\"fees_amount\":\"150\",\"header\":\"Environment Studies Fees\",\"header_id\":\"34\"},{\"fees_amount\":\"75\",\"header\":\"Provisional Passing Certficate Fees\",\"header_id\":\"35\"},{\"fees_amount\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\"},{\"fees_amount\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\"},{\"fees_amount\":\"32\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\"},{\"fees_amount\":\"50\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\"}]}]');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `courses_id` int(11) NOT NULL,
  `courses_name` text,
  `short_courses` text,
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(10) NOT NULL DEFAULT '0',
  `on_update` timestamp NULL DEFAULT NULL,
  `is_educational` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`courses_id`, `courses_name`, `short_courses`, `created_on`, `is_active`, `is_deleted`, `on_update`, `is_educational`) VALUES
(1, 'Under Graduation', 'U.G', '2021-02-27 17:33:32', 1, 0, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `employee_position`
--

CREATE TABLE `employee_position` (
  `employee_position_id` int(11) NOT NULL,
  `employee_position_title` varchar(100) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee_position`
--

INSERT INTO `employee_position` (`employee_position_id`, `employee_position_title`, `is_active`, `is_deleted`) VALUES
(1, 'Accountant', 1, 0),
(2, 'AICTE, NIRF, NBA, NAAC portals Incharge', 1, 0),
(3, 'Associate Professor', 1, 0),
(4, 'Asst. Professor', 1, 0),
(5, 'Asst.Librarian', 1, 0),
(6, 'Auto Mechanic', 1, 0),
(7, 'Black-Smith', 1, 0),
(8, 'Carpenter', 1, 0),
(9, 'Clerk-Cum-Typist', 1, 0),
(10, 'COE (Controller of Examination)', 1, 0),
(11, 'Contractual Engaged Faculty', 1, 0),
(12, 'Coordinator(Center of Excellence in Signal and Image Processing)', 1, 0),
(13, 'Dean (Academics)', 1, 0),
(14, 'Dean (Industry Liaison)', 1, 0),
(15, 'Dean (R&amp;D)', 1, 0),
(16, 'Dean (Students Affairs)', 1, 0),
(17, 'Dean(Finance and Resource Management)', 1, 0),
(18, 'Dean(Innovation Laboratory)', 1, 0),
(19, 'Dean(IT Services)', 1, 0),
(20, 'Dean(Planning)', 1, 0),
(21, 'Dean(Procurement)', 1, 0),
(22, 'Director', 1, 0),
(23, 'Draftsman', 1, 0),
(24, 'Driver', 1, 0),
(25, 'Electrician', 1, 0),
(26, 'First In-charge(UG)', 1, 0),
(27, 'Fitter', 1, 0),
(28, 'Foremen', 1, 0),
(29, 'Head Clerk', 1, 0),
(30, 'HOD', 1, 0),
(31, 'Hostel (Rector and Warden)', 1, 0),
(32, 'In-charge(All Institute  Websites)', 1, 0),
(33, 'In-charge(Campus Networking &amp; Central Computing Facility)', 1, 0),
(34, 'Lab. Assistant', 1, 0),
(35, 'Lab. Assistant (T)', 1, 0),
(36, 'Lab. Attendant', 1, 0),
(37, 'Librarian', 1, 0),
(38, 'Library Clerk', 1, 0),
(39, 'Machinist', 1, 0),
(40, 'Mali', 1, 0),
(41, 'Moulder', 1, 0),
(42, 'Peon', 1, 0),
(43, 'Plumber', 1, 0),
(44, 'Professor', 1, 0),
(45, 'Programmer', 1, 0),
(46, 'Purchase Commitee (Chairman)', 1, 0),
(47, 'Senior Clerk', 1, 0),
(48, 'Site Department/Section', 1, 0),
(49, 'Site Mistry', 1, 0),
(50, 'Sports In-charge', 1, 0),
(51, 'Sr. Lab. Asst.', 1, 0),
(52, 'Storekeeper', 1, 0),
(53, 'Sweeper', 1, 0),
(54, 'System Admin', 1, 0),
(55, 'T &amp; P Officer', 1, 0),
(56, 'TEQIP Coordinator', 1, 0),
(57, 'TIEC Coordinator', 1, 0),
(58, 'Turner', 1, 0),
(59, 'Welder', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `faculty_id` int(11) NOT NULL,
  `faculty_full_name` varchar(250) DEFAULT NULL,
  `is_senior` tinyint(1) DEFAULT '1',
  `email` varchar(100) DEFAULT NULL,
  `password_key` varchar(500) DEFAULT NULL,
  `login_status` tinyint(1) DEFAULT '0',
  `is_active` tinyint(10) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(10) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `on_update` timestamp NULL DEFAULT NULL,
  `mobile_phone` decimal(12,0) DEFAULT NULL,
  `biometric_ID` varchar(10) DEFAULT NULL,
  `faculty_image` varchar(50) DEFAULT NULL,
  `joining_date` date DEFAULT NULL,
  `gender` enum('Male','Female','Other','') DEFAULT NULL,
  `job_title` text,
  `employee_grade_name` text,
  `qualification_employee` varchar(100) DEFAULT NULL,
  `experience_detail_employee` varchar(100) NOT NULL,
  `before_joining_experience_in_year` decimal(10,0) NOT NULL,
  `experience_in_number_of_months` decimal(5,5) NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `marital_status_employee` enum('Married','Single') DEFAULT NULL,
  `children_count` decimal(2,0) NOT NULL,
  `father_name` text NOT NULL,
  `mother_name` text NOT NULL,
  `spouse_name` text NOT NULL,
  `home_address_line1` text,
  `home_address_line2` text,
  `city` text,
  `state` text,
  `country` text,
  `pin_code` decimal(6,0) DEFAULT NULL,
  `aadhar_number` decimal(12,2) DEFAULT NULL,
  `voter_id` varchar(12) DEFAULT NULL,
  `pan_no` varchar(7) DEFAULT NULL,
  `physically_handicapped` tinyint(1) DEFAULT '0',
  `super_annuation_age` decimal(3,0) DEFAULT NULL,
  `retiring_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fees_element`
--

CREATE TABLE `fees_element` (
  `fees_element_id` int(11) NOT NULL,
  `fees_element_title` text NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fees_element`
--

INSERT INTO `fees_element` (`fees_element_id`, `fees_element_title`, `is_active`, `is_deleted`) VALUES
(1, 'Registration Fees', 1, 0),
(2, 'Admission Fees', 1, 0),
(3, 'Library Deposit', 1, 0),
(4, 'Laboratory Fees', 1, 0),
(5, 'Magazine Fees', 1, 0),
(6, 'S.A.F. Fees', 1, 0),
(7, 'Games Fees(Gymkhana)', 1, 0),
(8, 'Gathering Fees', 1, 0),
(9, 'Library Fees', 1, 0),
(10, 'Student Well Fare Fees', 1, 0),
(11, 'College Development Fees', 1, 0),
(12, 'Identity Card Fees', 1, 0),
(13, 'Student Forum fees', 1, 0),
(14, 'Home Exam Fees', 1, 0),
(15, 'Medical Examination Fees', 1, 0),
(16, 'Project Fees', 1, 0),
(17, 'University Sports Fees', 1, 0),
(18, 'Miscellaneous Fees(Other fees)', 1, 0),
(19, 'T.C. Fees', 1, 0),
(20, 'Book Bank', 1, 0),
(21, 'Youth Festival', 1, 0),
(22, 'Ashwamedh', 1, 0),
(23, 'Emergency Fees', 1, 0),
(24, 'Students Insurance Fees', 1, 0),
(25, 'Eligibility Form', 1, 0),
(26, 'Eligibility Fees', 1, 0),
(27, 'University Exam Form', 1, 0),
(28, 'University Exam Fees', 1, 0),
(29, 'Practical Fees', 1, 0),
(30, 'University Exam Late Fees', 1, 0),
(31, 'Tution Fees', 1, 0),
(32, 'Verification at A.B.', 1, 0),
(33, 'Fine Fees', 1, 0),
(34, 'Environment Studies Fees', 1, 0),
(35, 'Provisional Passing Certficate Fees', 1, 0),
(36, 'Library Non.Recurring', 1, 0),
(37, 'E Suvidha', 1, 0),
(38, 'Chancellor\'s Office Activities Fees', 1, 0),
(39, 'Zonal Sports Council Fees', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `general_settings`
--

CREATE TABLE `general_settings` (
  `general_settings_id` int(11) NOT NULL,
  `type` varchar(1000) NOT NULL,
  `value` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `general_settings`
--

INSERT INTO `general_settings` (`general_settings_id`, `type`, `value`) VALUES
(1, 'smtp_host', 'ssl://mail.sggsmis.online'),
(2, 'smtp_port', '465'),
(3, 'smtp_user', 'support@sggsmis.online'),
(4, 'smtp_pass', 'X3%AR?+Xmzym'),
(5, 'mail_status', 'smtp');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(11) NOT NULL,
  `student_full_name` text,
  `father_full_name` text,
  `mother_full_name` text,
  `guardian_occupation` varchar(50) DEFAULT NULL,
  `family_income` varchar(10) DEFAULT NULL,
  `student_mobile_no` decimal(10,0) DEFAULT NULL,
  `landline` decimal(10,0) DEFAULT NULL,
  `student_personal_email_id` varchar(100) DEFAULT NULL,
  `guardian_mobile_no` decimal(10,0) DEFAULT NULL,
  `gender` enum('M','F','O') DEFAULT NULL,
  `mother_tongue` varchar(50) DEFAULT NULL,
  `birth_place` varchar(100) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `caste` varchar(100) DEFAULT NULL,
  `sub_caste` varchar(50) DEFAULT NULL,
  `religion` enum('HINDU','BUDDHIST','MUSLIM','ISLAM','CHRISTIAN','SIKHIISM','JAINISM','ZOROASTRIANISM','JUDAISM') DEFAULT NULL,
  `caste_category` enum('OPEN','OBC','NT-B','NT-C','NT-D','SC','ST','SBC','NT-A') DEFAULT NULL,
  `blood_group` enum('A+','A-','AB+','B+','B-','O+','O-') DEFAULT NULL,
  `physically_handicapped` enum('Y','N') DEFAULT NULL,
  `handicap_type` enum('Visual_Impairment','Hearing_Impairment','Speech_Impairment','Orthopedic_Disorder','Mentally_Retarded') DEFAULT NULL,
  `student_aadhar_no` decimal(12,0) DEFAULT NULL,
  `domicile_state` varchar(50) DEFAULT NULL,
  `permanent_country` varchar(50) DEFAULT NULL,
  `permanent_pin` varchar(50) DEFAULT NULL,
  `ssc_seat_no` varchar(50) DEFAULT NULL,
  `ssc_board_name` varchar(50) DEFAULT NULL,
  `ssc_pass_date` varchar(50) DEFAULT NULL,
  `ssc_school_college_name` varchar(100) DEFAULT NULL,
  `ssc_passing_cert_no` varchar(30) DEFAULT NULL,
  `ssc_out_of` int(5) DEFAULT NULL,
  `hsc_seat_no` varchar(50) DEFAULT NULL,
  `hsc_board_name` varchar(50) DEFAULT NULL,
  `hsc_pass_date` varchar(50) DEFAULT NULL,
  `hsc_school_college_name` varchar(50) DEFAULT NULL,
  `hsc_passing_cert_no` varchar(50) DEFAULT NULL,
  `hsc_out_of` int(5) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `academics` mediumtext,
  `is_deleted` tinyint(10) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `on_update` timestamp NULL DEFAULT NULL,
  `student_image` varchar(50) DEFAULT NULL,
  `student_signature` varchar(50) DEFAULT NULL,
  `ID_card_request` int(10) NOT NULL DEFAULT '0',
  `ID_card_given` int(10) NOT NULL DEFAULT '0',
  `login_status` tinyint(2) DEFAULT '0',
  `div` varchar(10) DEFAULT NULL,
  `admissionno` varchar(20) DEFAULT NULL,
  `branche_id` int(11) NOT NULL,
  `idcard_reject` enum('1','0') NOT NULL DEFAULT '0',
  `concession_fees` enum('EBC','SC','ST','NT','OBC','SBC','BC','PTC','STC','freedom_fighter','service_man','full_fees') DEFAULT NULL,
  `ssc_total_marks` varchar(50) DEFAULT NULL,
  `hsc_total_marks` varchar(50) DEFAULT NULL,
  `marital_status` enum('UNMARRIED','MARRIED','DIVORCED','WIDOWED','DESERTED') DEFAULT NULL,
  `social_reservation` enum('GOVT_OF_INDIA_POST_MATRIC_SCHOLARSHIP','RAJASHRI_CHHATRAPATI_SHAHU_MAHARAJ_MERIT_SCHOLARSHIP','DR_PUNJABRAO_DESHMUKH','POST_MATRIC_SCHOLARSHIP_SBC','POST_MATRIC_SCHOLARSHIP_OBC','POST_MATRIC_SCHOLARSHIP_VJNT','POST_MATRIC_TUTION_EXAMINATION_FEE_FREESHIP','1','2') DEFAULT NULL,
  `guardian_name` varchar(60) DEFAULT NULL,
  `guardian_relation` varchar(50) DEFAULT NULL,
  `employment_status` enum('EMPLOYED','UNEMPLOYED') DEFAULT NULL,
  `ncc_nss` enum('YES','NO') DEFAULT NULL,
  `hostel` enum('YES','NO') DEFAULT NULL,
  `ssc_cert` enum('original','attested','no') DEFAULT NULL,
  `hsc_cert` enum('original','attested','no') DEFAULT NULL,
  `leaving_cert` enum('original','attested','no') DEFAULT NULL,
  `attested_caste_cert` enum('attested','no') DEFAULT NULL,
  `attested_non_creamy` enum('attested','no') DEFAULT NULL,
  `affidavit_marriage_gazette` enum('attested','no') DEFAULT NULL,
  `domicile_cert` enum('attested','no') DEFAULT NULL,
  `phy_challenge_cert` enum('attested','no') DEFAULT NULL,
  `registration_form_cert` enum('original','attested','no') DEFAULT NULL,
  `admission_form_cert` enum('original','attested','no') DEFAULT NULL,
  `eligibility_cert` enum('original','attested','no') DEFAULT NULL,
  `incorme_cert` enum('original','attested','no') DEFAULT NULL,
  `migration_cert` enum('original','attested','no') DEFAULT NULL,
  `date_cert` enum('original','attested','no') DEFAULT NULL,
  `ebc_ptc_ff_gf_btc_cert` enum('original','attested','no') DEFAULT NULL,
  `gap_cert` enum('original','attested','no') DEFAULT NULL,
  `other_cert` enum('original','attested','no') DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `eligibility_no` varchar(50) DEFAULT NULL,
  `permanent_address` varchar(300) DEFAULT NULL,
  `correspondence_address` varchar(300) DEFAULT NULL,
  `last_college` varchar(50) DEFAULT NULL,
  `last_college_year` varchar(50) DEFAULT NULL,
  `last_college_roll` varchar(5) DEFAULT NULL,
  `hsc_done` enum('Yes','No') NOT NULL DEFAULT 'Yes',
  `ssc_done` enum('Yes','No') NOT NULL DEFAULT 'Yes',
  `markmemo_given` enum('YES','NO') DEFAULT NULL,
  `is_gap` enum('YES','NO') NOT NULL,
  `fees_installments` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `student_full_name`, `father_full_name`, `mother_full_name`, `guardian_occupation`, `family_income`, `student_mobile_no`, `landline`, `student_personal_email_id`, `guardian_mobile_no`, `gender`, `mother_tongue`, `birth_place`, `date_of_birth`, `caste`, `sub_caste`, `religion`, `caste_category`, `blood_group`, `physically_handicapped`, `handicap_type`, `student_aadhar_no`, `domicile_state`, `permanent_country`, `permanent_pin`, `ssc_seat_no`, `ssc_board_name`, `ssc_pass_date`, `ssc_school_college_name`, `ssc_passing_cert_no`, `ssc_out_of`, `hsc_seat_no`, `hsc_board_name`, `hsc_pass_date`, `hsc_school_college_name`, `hsc_passing_cert_no`, `hsc_out_of`, `is_active`, `academics`, `is_deleted`, `created_on`, `on_update`, `student_image`, `student_signature`, `ID_card_request`, `ID_card_given`, `login_status`, `div`, `admissionno`, `branche_id`, `idcard_reject`, `concession_fees`, `ssc_total_marks`, `hsc_total_marks`, `marital_status`, `social_reservation`, `guardian_name`, `guardian_relation`, `employment_status`, `ncc_nss`, `hostel`, `ssc_cert`, `hsc_cert`, `leaving_cert`, `attested_caste_cert`, `attested_non_creamy`, `affidavit_marriage_gazette`, `domicile_cert`, `phy_challenge_cert`, `registration_form_cert`, `admission_form_cert`, `eligibility_cert`, `incorme_cert`, `migration_cert`, `date_cert`, `ebc_ptc_ff_gf_btc_cert`, `gap_cert`, `other_cert`, `course_id`, `eligibility_no`, `permanent_address`, `correspondence_address`, `last_college`, `last_college_year`, `last_college_roll`, `hsc_done`, `ssc_done`, `markmemo_given`, `is_gap`, `fees_installments`) VALUES
(1, 'abcd', 'abcd', 'abcd', 'Service', 'abcd', '0', '0', 'abcd', '1', 'F', 'abcd', 'abcd', '2021-12-12', 'abcd', 'abcd', 'HINDU', 'OPEN', 'A+', 'N', 'Visual_Impairment', '0', 'abcd', 'abcd', 'abcd', '1', 'abcd', '2021-12-12', 'abcd', '1', 1, '1', 'abcd', '2021-12-12', 'abcd', '1', 1, 1, '[{\"year_id\":\"2\",\"current_branch\":\"1\",\"academic_year_id\":\"1\",\"currently\":\"Y\",\"subject\":{\"compulsary\":\"English\",\"secondary\":\"2\",\"optional_subject_1\":\"5\",\"optional_subject_2\":\"5\",\"optional_subject_3\":\"5\",\"optional_subject_4\":\"5\",\"optional_subject_5\":\"5\",\"optional_subject_6\":\"5\",\"optional_subject_7\":\"5\",\"optional_subject_8\":\"5\",\"optional_subject_9\":\"5\"},\"eligible_for_exam\":\"Y\",\"class_name\":\"\",\"admission_confirm\":\"Y\",\"admission_date\":false,\"maha_dbt_id\":\"\",\"fullfees\":\"EBC\",\"fees_deatails\":\"\",\"hostel_requested\":\"YES\",\"hostel_approved\":\"\",\"hostel_details\":\"\",\"mahadbt_id\":\"\"}]', 0, '2021-10-04 02:44:35', NULL, '', '', 0, 0, 0, 'abcd', 'abcd', 1, '0', 'EBC', '1', '1', 'UNMARRIED', 'GOVT_OF_INDIA_POST_MATRIC_SCHOLARSHIP', 'abcd', 'abcd', 'EMPLOYED', 'YES', 'YES', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 1, 'abcd', 'abcd', 'abcd', 'abcd', 'abcd', 'abcd', 'Yes', 'Yes', 'YES', 'YES', '[{\"year_id\":\"2\",\"paid_date\":\"05\\/10\\/2021\",\"fees_paid_with_header\":[{\"fees_paid\":\"10\",\"header\":\"Registration Fees\",\"header_id\":\"1\",\"fees_amount\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"Admission Fees\",\"header_id\":\"2\",\"fees_amount\":\"40\"},{\"fees_paid\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\",\"fees_amount\":\"0\"},{\"fees_paid\":\"50\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\",\"fees_amount\":\"150\"},{\"fees_paid\":\"0\",\"header\":\"Magazine Fees\",\"header_id\":\"5\",\"fees_amount\":\"60\"},{\"fees_paid\":\"0\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\",\"fees_amount\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\",\"fees_amount\":\"50\"},{\"fees_paid\":\"0\",\"header\":\"Gathering Fees\",\"header_id\":\"8\",\"fees_amount\":\"60\"},{\"fees_paid\":\"0\",\"header\":\"Library Fees\",\"header_id\":\"9\",\"fees_amount\":\"150\"},{\"fees_paid\":\"0\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\",\"fees_amount\":\"60\"},{\"fees_paid\":\"0\",\"header\":\"College Development Fees\",\"header_id\":\"11\",\"fees_amount\":\"50\"},{\"fees_paid\":\"0\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\",\"fees_amount\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"Student Forum fees\",\"header_id\":\"13\",\"fees_amount\":\"15\"},{\"fees_paid\":\"0\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\",\"fees_amount\":\"30\"},{\"fees_paid\":\"0\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\",\"fees_amount\":\"5\"},{\"fees_paid\":\"0\",\"header\":\"Project Fees\",\"header_id\":\"16\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"University Sports Fees\",\"header_id\":\"17\",\"fees_amount\":\"50\"},{\"fees_paid\":\"0\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\",\"fees_amount\":\"20\"},{\"fees_paid\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Book Bank\",\"header_id\":\"20\",\"fees_amount\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"Youth Festival\",\"header_id\":\"21\",\"fees_amount\":\"50\"},{\"fees_paid\":\"0\",\"header\":\"Ashwamedh\",\"header_id\":\"22\",\"fees_amount\":\"30\"},{\"fees_paid\":\"0\",\"header\":\"Emergency Fees\",\"header_id\":\"23\",\"fees_amount\":\"15\"},{\"fees_paid\":\"0\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\",\"fees_amount\":\"8\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Tution Fees\",\"header_id\":\"31\",\"fees_amount\":\"1000\"},{\"fees_paid\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Environment Studies Fees\",\"header_id\":\"34\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Provisional Passing Certficate Fees\",\"header_id\":\"35\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\",\"fees_amount\":\"32\"},{\"fees_paid\":\"0\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\",\"fees_amount\":\"50\"}]}]'),
(2, 'kunal sanjay danole', 'sanjay', 'JAYASHREE', 'Business', '111000', '9834091915', '2462', 'kunal@gmail.com', '989988998', 'M', 'marathi', 'NANDED', '1994-01-24', 'jain', 'chaturth', 'HINDU', 'OPEN', 'O+', 'Y', 'Visual_Impairment', '999999999999', 'maharashtra', 'india', '431605', '12', '1', '2020-01-01', '1', '12', 0, '21', '2', '2020-02-02', '2', '12', 0, 1, '[{\"year_id\":\"2\",\"current_branch\":\"1\",\"academic_year_id\":\"1\",\"currently\":\"Y\",\"subject\":{\"compulsary\":\"15\",\"secondary\":\"18\",\"optional_subject_1\":\"19\",\"optional_subject_2\":\"27\",\"optional_subject_3\":\"26\",\"optional_subject_4\":\"25\",\"optional_subject_5\":\"24\",\"optional_subject_6\":\"23\",\"optional_subject_7\":\"22\",\"optional_subject_8\":\"21\",\"optional_subject_9\":\"20\"},\"eligible_for_exam\":\"Y\",\"class_name\":\"\",\"admission_confirm\":\"Y\",\"admission_date\":false,\"maha_dbt_id\":\"\",\"fullfees\":\"EBC\",\"fees_deatails\":\"\",\"hostel_requested\":\"NO\",\"hostel_approved\":\"\",\"hostel_details\":\"\",\"mahadbt_id\":\"\"}]', 0, '2021-10-04 02:45:54', NULL, '', '', 0, 0, 0, 'A', '101', 1, '0', 'EBC', '650', '550', 'UNMARRIED', 'POST_MATRIC_SCHOLARSHIP_VJNT', 'sanjay', 'father', 'UNEMPLOYED', 'NO', 'NO', 'original', 'original', 'original', 'attested', 'attested', 'attested', 'attested', 'attested', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 1, '1010', 'nanded', 'nanded', 'mgm', '2020', '8', 'Yes', 'Yes', 'YES', 'YES', '[{\"year_id\":\"2\",\"paid_date\":\"05\\/10\\/2021\",\"fees_paid_with_header\":[{\"fees_paid\":\"0\",\"header\":\"Registration Fees\",\"header_id\":\"1\",\"fees_amount\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"Admission Fees\",\"header_id\":\"2\",\"fees_amount\":\"40\"},{\"fees_paid\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\",\"fees_amount\":\"150\"},{\"fees_paid\":\"0\",\"header\":\"Magazine Fees\",\"header_id\":\"5\",\"fees_amount\":\"60\"},{\"fees_paid\":\"0\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\",\"fees_amount\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\",\"fees_amount\":\"50\"},{\"fees_paid\":\"0\",\"header\":\"Gathering Fees\",\"header_id\":\"8\",\"fees_amount\":\"60\"},{\"fees_paid\":\"0\",\"header\":\"Library Fees\",\"header_id\":\"9\",\"fees_amount\":\"150\"},{\"fees_paid\":\"0\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\",\"fees_amount\":\"60\"},{\"fees_paid\":\"0\",\"header\":\"College Development Fees\",\"header_id\":\"11\",\"fees_amount\":\"50\"},{\"fees_paid\":\"0\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\",\"fees_amount\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"Student Forum fees\",\"header_id\":\"13\",\"fees_amount\":\"15\"},{\"fees_paid\":\"0\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\",\"fees_amount\":\"30\"},{\"fees_paid\":\"0\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\",\"fees_amount\":\"5\"},{\"fees_paid\":\"0\",\"header\":\"Project Fees\",\"header_id\":\"16\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"University Sports Fees\",\"header_id\":\"17\",\"fees_amount\":\"50\"},{\"fees_paid\":\"0\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\",\"fees_amount\":\"20\"},{\"fees_paid\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Book Bank\",\"header_id\":\"20\",\"fees_amount\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"Youth Festival\",\"header_id\":\"21\",\"fees_amount\":\"50\"},{\"fees_paid\":\"0\",\"header\":\"Ashwamedh\",\"header_id\":\"22\",\"fees_amount\":\"30\"},{\"fees_paid\":\"0\",\"header\":\"Emergency Fees\",\"header_id\":\"23\",\"fees_amount\":\"15\"},{\"fees_paid\":\"0\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\",\"fees_amount\":\"8\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Tution Fees\",\"header_id\":\"31\",\"fees_amount\":\"1000\"},{\"fees_paid\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Environment Studies Fees\",\"header_id\":\"34\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Provisional Passing Certficate Fees\",\"header_id\":\"35\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\",\"fees_amount\":\"0\"},{\"fees_paid\":\"32\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\",\"fees_amount\":\"32\"},{\"fees_paid\":\"0\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\",\"fees_amount\":\"50\"}]},{\"year_id\":\"2\",\"paid_date\":\"05\\/10\\/2021\",\"fees_paid_with_header\":[{\"fees_paid\":\"10\",\"header\":\"Registration Fees\",\"header_id\":\"1\"},{\"fees_paid\":\"0\",\"header\":\"Admission Fees\",\"header_id\":\"2\"},{\"fees_paid\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\"},{\"fees_paid\":\"0\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\"},{\"fees_paid\":\"0\",\"header\":\"Magazine Fees\",\"header_id\":\"5\"},{\"fees_paid\":\"0\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\"},{\"fees_paid\":\"0\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\"},{\"fees_paid\":\"0\",\"header\":\"Gathering Fees\",\"header_id\":\"8\"},{\"fees_paid\":\"0\",\"header\":\"Library Fees\",\"header_id\":\"9\"},{\"fees_paid\":\"0\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"College Development Fees\",\"header_id\":\"11\"},{\"fees_paid\":\"0\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\"},{\"fees_paid\":\"0\",\"header\":\"Student Forum fees\",\"header_id\":\"13\"},{\"fees_paid\":\"0\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\"},{\"fees_paid\":\"0\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\"},{\"fees_paid\":\"0\",\"header\":\"Project Fees\",\"header_id\":\"16\"},{\"fees_paid\":\"0\",\"header\":\"University Sports Fees\",\"header_id\":\"17\"},{\"fees_paid\":\"0\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\"},{\"fees_paid\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\"},{\"fees_paid\":\"0\",\"header\":\"Book Bank\",\"header_id\":\"20\"},{\"fees_paid\":\"0\",\"header\":\"Youth Festival\",\"header_id\":\"21\"},{\"fees_paid\":\"0\",\"header\":\"Ashwamedh\",\"header_id\":\"22\"},{\"fees_paid\":\"0\",\"header\":\"Emergency Fees\",\"header_id\":\"23\"},{\"fees_paid\":\"0\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\"},{\"fees_paid\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\"},{\"fees_paid\":\"0\",\"header\":\"Tution Fees\",\"header_id\":\"31\"},{\"fees_paid\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\"},{\"fees_paid\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\"},{\"fees_paid\":\"0\",\"header\":\"Environment Studies Fees\",\"header_id\":\"34\"},{\"fees_paid\":\"0\",\"header\":\"Provisional Passing Certficate Fees\",\"header_id\":\"35\"},{\"fees_paid\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\"},{\"fees_paid\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\"},{\"fees_paid\":\"0\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\"},{\"fees_paid\":\"0\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\"}]},{\"year_id\":\"2\",\"paid_date\":\"05\\/10\\/2021\",\"fees_paid_with_header\":[{\"fees_paid\":\"0\",\"header\":\"Registration Fees\",\"header_id\":\"1\"},{\"fees_paid\":\"40\",\"header\":\"Admission Fees\",\"header_id\":\"2\"},{\"fees_paid\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\"},{\"fees_paid\":\"0\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\"},{\"fees_paid\":\"0\",\"header\":\"Magazine Fees\",\"header_id\":\"5\"},{\"fees_paid\":\"0\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\"},{\"fees_paid\":\"0\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\"},{\"fees_paid\":\"0\",\"header\":\"Gathering Fees\",\"header_id\":\"8\"},{\"fees_paid\":\"0\",\"header\":\"Library Fees\",\"header_id\":\"9\"},{\"fees_paid\":\"0\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"College Development Fees\",\"header_id\":\"11\"},{\"fees_paid\":\"0\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\"},{\"fees_paid\":\"0\",\"header\":\"Student Forum fees\",\"header_id\":\"13\"},{\"fees_paid\":\"0\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\"},{\"fees_paid\":\"0\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\"},{\"fees_paid\":\"0\",\"header\":\"Project Fees\",\"header_id\":\"16\"},{\"fees_paid\":\"0\",\"header\":\"University Sports Fees\",\"header_id\":\"17\"},{\"fees_paid\":\"0\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\"},{\"fees_paid\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\"},{\"fees_paid\":\"0\",\"header\":\"Book Bank\",\"header_id\":\"20\"},{\"fees_paid\":\"0\",\"header\":\"Youth Festival\",\"header_id\":\"21\"},{\"fees_paid\":\"0\",\"header\":\"Ashwamedh\",\"header_id\":\"22\"},{\"fees_paid\":\"0\",\"header\":\"Emergency Fees\",\"header_id\":\"23\"},{\"fees_paid\":\"0\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\"},{\"fees_paid\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\"},{\"fees_paid\":\"0\",\"header\":\"Tution Fees\",\"header_id\":\"31\"},{\"fees_paid\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\"},{\"fees_paid\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\"},{\"fees_paid\":\"0\",\"header\":\"Environment Studies Fees\",\"header_id\":\"34\"},{\"fees_paid\":\"0\",\"header\":\"Provisional Passing Certficate Fees\",\"header_id\":\"35\"},{\"fees_paid\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\"},{\"fees_paid\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\"},{\"fees_paid\":\"0\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\"},{\"fees_paid\":\"0\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\"}]},{\"year_id\":\"2\",\"paid_date\":\"05\\/10\\/2021\",\"fees_paid_with_header\":[{\"fees_paid\":\"0\",\"header\":\"Registration Fees\",\"header_id\":\"1\"},{\"fees_paid\":\"0\",\"header\":\"Admission Fees\",\"header_id\":\"2\"},{\"fees_paid\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\"},{\"fees_paid\":\"150\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\"},{\"fees_paid\":\"0\",\"header\":\"Magazine Fees\",\"header_id\":\"5\"},{\"fees_paid\":\"0\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\"},{\"fees_paid\":\"0\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\"},{\"fees_paid\":\"0\",\"header\":\"Gathering Fees\",\"header_id\":\"8\"},{\"fees_paid\":\"0\",\"header\":\"Library Fees\",\"header_id\":\"9\"},{\"fees_paid\":\"0\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"College Development Fees\",\"header_id\":\"11\"},{\"fees_paid\":\"0\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\"},{\"fees_paid\":\"0\",\"header\":\"Student Forum fees\",\"header_id\":\"13\"},{\"fees_paid\":\"0\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\"},{\"fees_paid\":\"0\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\"},{\"fees_paid\":\"0\",\"header\":\"Project Fees\",\"header_id\":\"16\"},{\"fees_paid\":\"0\",\"header\":\"University Sports Fees\",\"header_id\":\"17\"},{\"fees_paid\":\"0\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\"},{\"fees_paid\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\"},{\"fees_paid\":\"0\",\"header\":\"Book Bank\",\"header_id\":\"20\"},{\"fees_paid\":\"0\",\"header\":\"Youth Festival\",\"header_id\":\"21\"},{\"fees_paid\":\"0\",\"header\":\"Ashwamedh\",\"header_id\":\"22\"},{\"fees_paid\":\"0\",\"header\":\"Emergency Fees\",\"header_id\":\"23\"},{\"fees_paid\":\"0\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\"},{\"fees_paid\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\"},{\"fees_paid\":\"0\",\"header\":\"Tution Fees\",\"header_id\":\"31\"},{\"fees_paid\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\"},{\"fees_paid\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\"},{\"fees_paid\":\"0\",\"header\":\"Environment Studies Fees\",\"header_id\":\"34\"},{\"fees_paid\":\"0\",\"header\":\"Provisional Passing Certficate Fees\",\"header_id\":\"35\"},{\"fees_paid\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\"},{\"fees_paid\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\"},{\"fees_paid\":\"0\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\"},{\"fees_paid\":\"0\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\"}]},{\"year_id\":\"2\",\"paid_date\":\"05\\/10\\/2021\",\"fees_paid_with_header\":[{\"fees_paid\":\"0\",\"header\":\"Registration Fees\",\"header_id\":\"1\"},{\"fees_paid\":\"0\",\"header\":\"Admission Fees\",\"header_id\":\"2\"},{\"fees_paid\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\"},{\"fees_paid\":\"0\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\"},{\"fees_paid\":\"0\",\"header\":\"Magazine Fees\",\"header_id\":\"5\"},{\"fees_paid\":\"0\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\"},{\"fees_paid\":\"0\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\"},{\"fees_paid\":\"0\",\"header\":\"Gathering Fees\",\"header_id\":\"8\"},{\"fees_paid\":\"0\",\"header\":\"Library Fees\",\"header_id\":\"9\"},{\"fees_paid\":\"0\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"College Development Fees\",\"header_id\":\"11\"},{\"fees_paid\":\"0\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\"},{\"fees_paid\":\"0\",\"header\":\"Student Forum fees\",\"header_id\":\"13\"},{\"fees_paid\":\"0\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\"},{\"fees_paid\":\"0\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\"},{\"fees_paid\":\"0\",\"header\":\"Project Fees\",\"header_id\":\"16\"},{\"fees_paid\":\"0\",\"header\":\"University Sports Fees\",\"header_id\":\"17\"},{\"fees_paid\":\"0\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\"},{\"fees_paid\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\"},{\"fees_paid\":\"0\",\"header\":\"Book Bank\",\"header_id\":\"20\"},{\"fees_paid\":\"0\",\"header\":\"Youth Festival\",\"header_id\":\"21\"},{\"fees_paid\":\"0\",\"header\":\"Ashwamedh\",\"header_id\":\"22\"},{\"fees_paid\":\"0\",\"header\":\"Emergency Fees\",\"header_id\":\"23\"},{\"fees_paid\":\"0\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\"},{\"fees_paid\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\"},{\"fees_paid\":\"1000\",\"header\":\"Tution Fees\",\"header_id\":\"31\"},{\"fees_paid\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\"},{\"fees_paid\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\"},{\"fees_paid\":\"0\",\"header\":\"Environment Studies Fees\",\"header_id\":\"34\"},{\"fees_paid\":\"0\",\"header\":\"Provisional Passing Certficate Fees\",\"header_id\":\"35\"},{\"fees_paid\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\"},{\"fees_paid\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\"},{\"fees_paid\":\"0\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\"},{\"fees_paid\":\"0\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\"}]},{\"year_id\":\"2\",\"paid_date\":\"05\\/10\\/2021\",\"fees_paid_with_header\":[{\"fees_paid\":\"0\",\"header\":\"Registration Fees\",\"header_id\":\"1\"},{\"fees_paid\":\"0\",\"header\":\"Admission Fees\",\"header_id\":\"2\"},{\"fees_paid\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\"},{\"fees_paid\":\"0\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\"},{\"fees_paid\":\"601\",\"header\":\"Magazine Fees\",\"header_id\":\"5\"},{\"fees_paid\":\"0\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\"},{\"fees_paid\":\"0\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\"},{\"fees_paid\":\"0\",\"header\":\"Gathering Fees\",\"header_id\":\"8\"},{\"fees_paid\":\"0\",\"header\":\"Library Fees\",\"header_id\":\"9\"},{\"fees_paid\":\"0\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"College Development Fees\",\"header_id\":\"11\"},{\"fees_paid\":\"0\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\"},{\"fees_paid\":\"0\",\"header\":\"Student Forum fees\",\"header_id\":\"13\"},{\"fees_paid\":\"0\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\"},{\"fees_paid\":\"0\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\"},{\"fees_paid\":\"0\",\"header\":\"Project Fees\",\"header_id\":\"16\"},{\"fees_paid\":\"0\",\"header\":\"University Sports Fees\",\"header_id\":\"17\"},{\"fees_paid\":\"0\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\"},{\"fees_paid\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\"},{\"fees_paid\":\"0\",\"header\":\"Book Bank\",\"header_id\":\"20\"},{\"fees_paid\":\"0\",\"header\":\"Youth Festival\",\"header_id\":\"21\"},{\"fees_paid\":\"0\",\"header\":\"Ashwamedh\",\"header_id\":\"22\"},{\"fees_paid\":\"0\",\"header\":\"Emergency Fees\",\"header_id\":\"23\"},{\"fees_paid\":\"0\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\"},{\"fees_paid\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\"},{\"fees_paid\":\"0\",\"header\":\"Tution Fees\",\"header_id\":\"31\"},{\"fees_paid\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\"},{\"fees_paid\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\"},{\"fees_paid\":\"0\",\"header\":\"Environment Studies Fees\",\"header_id\":\"34\"},{\"fees_paid\":\"0\",\"header\":\"Provisional Passing Certficate Fees\",\"header_id\":\"35\"},{\"fees_paid\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\"},{\"fees_paid\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\"},{\"fees_paid\":\"0\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\"},{\"fees_paid\":\"0\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\"}]}]');
INSERT INTO `student` (`student_id`, `student_full_name`, `father_full_name`, `mother_full_name`, `guardian_occupation`, `family_income`, `student_mobile_no`, `landline`, `student_personal_email_id`, `guardian_mobile_no`, `gender`, `mother_tongue`, `birth_place`, `date_of_birth`, `caste`, `sub_caste`, `religion`, `caste_category`, `blood_group`, `physically_handicapped`, `handicap_type`, `student_aadhar_no`, `domicile_state`, `permanent_country`, `permanent_pin`, `ssc_seat_no`, `ssc_board_name`, `ssc_pass_date`, `ssc_school_college_name`, `ssc_passing_cert_no`, `ssc_out_of`, `hsc_seat_no`, `hsc_board_name`, `hsc_pass_date`, `hsc_school_college_name`, `hsc_passing_cert_no`, `hsc_out_of`, `is_active`, `academics`, `is_deleted`, `created_on`, `on_update`, `student_image`, `student_signature`, `ID_card_request`, `ID_card_given`, `login_status`, `div`, `admissionno`, `branche_id`, `idcard_reject`, `concession_fees`, `ssc_total_marks`, `hsc_total_marks`, `marital_status`, `social_reservation`, `guardian_name`, `guardian_relation`, `employment_status`, `ncc_nss`, `hostel`, `ssc_cert`, `hsc_cert`, `leaving_cert`, `attested_caste_cert`, `attested_non_creamy`, `affidavit_marriage_gazette`, `domicile_cert`, `phy_challenge_cert`, `registration_form_cert`, `admission_form_cert`, `eligibility_cert`, `incorme_cert`, `migration_cert`, `date_cert`, `ebc_ptc_ff_gf_btc_cert`, `gap_cert`, `other_cert`, `course_id`, `eligibility_no`, `permanent_address`, `correspondence_address`, `last_college`, `last_college_year`, `last_college_roll`, `hsc_done`, `ssc_done`, `markmemo_given`, `is_gap`, `fees_installments`) VALUES
(11, 'a', 'a', 'a', 'Service', 'a', '0', '0', 'a', '1', 'M', 'a', 'a', '2020-02-02', 'a', 'a', 'HINDU', 'OPEN', 'B+', 'Y', 'Visual_Impairment', '0', 'a', 'a', 'a', '1', '1', '2020-11-11', '1', '1', 11, '2', '1', '2020-02-11', '1', '2', 2, 1, '[{\"year_id\":\"2\",\"current_branch\":\"1\",\"academic_year_id\":\"1\",\"currently\":\"Y\",\"subject\":{\"compulsary\":\"15\",\"secondary\":\"16\",\"optional_subject_1\":\"19\",\"optional_subject_2\":\"20\",\"optional_subject_3\":\"21\",\"optional_subject_4\":\"22\",\"optional_subject_5\":\"23\",\"optional_subject_6\":\"24\",\"optional_subject_7\":\"25\",\"optional_subject_8\":\"25\",\"optional_subject_9\":\"26\"},\"eligible_for_exam\":\"Y\",\"class_name\":\"SY\",\"admission_confirm\":\"Y\",\"admission_date\":\"04-10-2021\",\"maha_dbt_id\":\"\",\"fullfees\":\"SC\",\"fees_deatails\":\"\",\"hostel_requested\":\"Yes\",\"hostel_approved\":\"\",\"hostel_details\":\"\",\"mahadbt_id\":\"\"}]', 0, '2021-10-04 16:56:53', NULL, '', '', 0, 0, 0, 'a', 'a', 1, '0', 'SC', '1', '2', 'UNMARRIED', 'GOVT_OF_INDIA_POST_MATRIC_SCHOLARSHIP', 'a', 'aa', 'EMPLOYED', 'YES', 'YES', 'original', 'original', 'original', 'attested', 'attested', 'attested', 'attested', 'attested', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 1, 'a', 'a', 'a', 'a', 'a', 'a', 'Yes', 'Yes', 'YES', 'YES', '[{\"year_id\":\"2\",\"paid_date\":\"05\\/10\\/2021\",\"fees_paid_with_header\":[{\"fees_paid\":\"10\",\"header\":\"Registration Fees\",\"header_id\":\"1\",\"fees_amount\":\"10\"},{\"fees_paid\":\"40\",\"header\":\"Admission Fees\",\"header_id\":\"2\",\"fees_amount\":\"40\"},{\"fees_paid\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\",\"fees_amount\":\"0\"},{\"fees_paid\":\"150\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\",\"fees_amount\":\"150\"},{\"fees_paid\":\"0\",\"header\":\"Magazine Fees\",\"header_id\":\"5\",\"fees_amount\":\"60\"},{\"fees_paid\":\"0\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\",\"fees_amount\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\",\"fees_amount\":\"50\"},{\"fees_paid\":\"0\",\"header\":\"Gathering Fees\",\"header_id\":\"8\",\"fees_amount\":\"60\"},{\"fees_paid\":\"0\",\"header\":\"Library Fees\",\"header_id\":\"9\",\"fees_amount\":\"150\"},{\"fees_paid\":\"0\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\",\"fees_amount\":\"60\"},{\"fees_paid\":\"0\",\"header\":\"College Development Fees\",\"header_id\":\"11\",\"fees_amount\":\"50\"},{\"fees_paid\":\"0\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\",\"fees_amount\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"Student Forum fees\",\"header_id\":\"13\",\"fees_amount\":\"15\"},{\"fees_paid\":\"0\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\",\"fees_amount\":\"30\"},{\"fees_paid\":\"0\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\",\"fees_amount\":\"5\"},{\"fees_paid\":\"0\",\"header\":\"Project Fees\",\"header_id\":\"16\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"University Sports Fees\",\"header_id\":\"17\",\"fees_amount\":\"50\"},{\"fees_paid\":\"0\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\",\"fees_amount\":\"20\"},{\"fees_paid\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Book Bank\",\"header_id\":\"20\",\"fees_amount\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"Youth Festival\",\"header_id\":\"21\",\"fees_amount\":\"50\"},{\"fees_paid\":\"0\",\"header\":\"Ashwamedh\",\"header_id\":\"22\",\"fees_amount\":\"30\"},{\"fees_paid\":\"0\",\"header\":\"Emergency Fees\",\"header_id\":\"23\",\"fees_amount\":\"15\"},{\"fees_paid\":\"0\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\",\"fees_amount\":\"8\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Tution Fees\",\"header_id\":\"31\",\"fees_amount\":\"1000\"},{\"fees_paid\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Environment Studies Fees\",\"header_id\":\"34\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Provisional Passing Certficate Fees\",\"header_id\":\"35\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\",\"fees_amount\":\"32\"},{\"fees_paid\":\"0\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\",\"fees_amount\":\"50\"}]},{\"year_id\":\"2\",\"paid_date\":\"05\\/10\\/2021\",\"fees_paid_with_header\":[{\"fees_paid\":\"0\",\"header\":\"Registration Fees\",\"header_id\":\"1\"},{\"fees_paid\":\"0\",\"header\":\"Admission Fees\",\"header_id\":\"2\"},{\"fees_paid\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\"},{\"fees_paid\":\"0\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\"},{\"fees_paid\":\"0\",\"header\":\"Magazine Fees\",\"header_id\":\"5\"},{\"fees_paid\":\"0\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\"},{\"fees_paid\":\"0\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\"},{\"fees_paid\":\"0\",\"header\":\"Gathering Fees\",\"header_id\":\"8\"},{\"fees_paid\":\"0\",\"header\":\"Library Fees\",\"header_id\":\"9\"},{\"fees_paid\":\"0\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"College Development Fees\",\"header_id\":\"11\"},{\"fees_paid\":\"0\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\"},{\"fees_paid\":\"0\",\"header\":\"Student Forum fees\",\"header_id\":\"13\"},{\"fees_paid\":\"0\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\"},{\"fees_paid\":\"0\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\"},{\"fees_paid\":\"0\",\"header\":\"Project Fees\",\"header_id\":\"16\"},{\"fees_paid\":\"0\",\"header\":\"University Sports Fees\",\"header_id\":\"17\"},{\"fees_paid\":\"0\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\"},{\"fees_paid\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\"},{\"fees_paid\":\"0\",\"header\":\"Book Bank\",\"header_id\":\"20\"},{\"fees_paid\":\"0\",\"header\":\"Youth Festival\",\"header_id\":\"21\"},{\"fees_paid\":\"0\",\"header\":\"Ashwamedh\",\"header_id\":\"22\"},{\"fees_paid\":\"0\",\"header\":\"Emergency Fees\",\"header_id\":\"23\"},{\"fees_paid\":\"0\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\"},{\"fees_paid\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\"},{\"fees_paid\":\"0\",\"header\":\"Tution Fees\",\"header_id\":\"31\"},{\"fees_paid\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\"},{\"fees_paid\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\"},{\"fees_paid\":\"0\",\"header\":\"Environment Studies Fees\",\"header_id\":\"34\"},{\"fees_paid\":\"0\",\"header\":\"Provisional Passing Certficate Fees\",\"header_id\":\"35\"},{\"fees_paid\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\"},{\"fees_paid\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\"},{\"fees_paid\":\"32\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\"},{\"fees_paid\":\"50\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\"}]},{\"year_id\":\"2\",\"paid_date\":\"05\\/10\\/2021\",\"fees_paid_with_header\":[{\"fees_paid\":\"0\",\"header\":\"Registration Fees\",\"header_id\":\"1\"},{\"fees_paid\":\"0\",\"header\":\"Admission Fees\",\"header_id\":\"2\"},{\"fees_paid\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\"},{\"fees_paid\":\"0\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\"},{\"fees_paid\":\"0\",\"header\":\"Magazine Fees\",\"header_id\":\"5\"},{\"fees_paid\":\"0\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\"},{\"fees_paid\":\"0\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\"},{\"fees_paid\":\"0\",\"header\":\"Gathering Fees\",\"header_id\":\"8\"},{\"fees_paid\":\"100\",\"header\":\"Library Fees\",\"header_id\":\"9\"},{\"fees_paid\":\"0\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"College Development Fees\",\"header_id\":\"11\"},{\"fees_paid\":\"0\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\"},{\"fees_paid\":\"0\",\"header\":\"Student Forum fees\",\"header_id\":\"13\"},{\"fees_paid\":\"0\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\"},{\"fees_paid\":\"0\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\"},{\"fees_paid\":\"0\",\"header\":\"Project Fees\",\"header_id\":\"16\"},{\"fees_paid\":\"0\",\"header\":\"University Sports Fees\",\"header_id\":\"17\"},{\"fees_paid\":\"0\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\"},{\"fees_paid\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\"},{\"fees_paid\":\"0\",\"header\":\"Book Bank\",\"header_id\":\"20\"},{\"fees_paid\":\"0\",\"header\":\"Youth Festival\",\"header_id\":\"21\"},{\"fees_paid\":\"0\",\"header\":\"Ashwamedh\",\"header_id\":\"22\"},{\"fees_paid\":\"0\",\"header\":\"Emergency Fees\",\"header_id\":\"23\"},{\"fees_paid\":\"0\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\"},{\"fees_paid\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\"},{\"fees_paid\":\"0\",\"header\":\"Tution Fees\",\"header_id\":\"31\"},{\"fees_paid\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\"},{\"fees_paid\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\"},{\"fees_paid\":\"0\",\"header\":\"Environment Studies Fees\",\"header_id\":\"34\"},{\"fees_paid\":\"0\",\"header\":\"Provisional Passing Certficate Fees\",\"header_id\":\"35\"},{\"fees_paid\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\"},{\"fees_paid\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\"},{\"fees_paid\":\"0\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\"},{\"fees_paid\":\"0\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\"}]},{\"year_id\":\"2\",\"paid_date\":\"05\\/10\\/2021\",\"fees_paid_with_header\":[{\"fees_paid\":\"0\",\"header\":\"Registration Fees\",\"header_id\":\"1\"},{\"fees_paid\":\"0\",\"header\":\"Admission Fees\",\"header_id\":\"2\"},{\"fees_paid\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\"},{\"fees_paid\":\"0\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\"},{\"fees_paid\":\"0\",\"header\":\"Magazine Fees\",\"header_id\":\"5\"},{\"fees_paid\":\"0\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\"},{\"fees_paid\":\"0\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\"},{\"fees_paid\":\"0\",\"header\":\"Gathering Fees\",\"header_id\":\"8\"},{\"fees_paid\":\"50\",\"header\":\"Library Fees\",\"header_id\":\"9\"},{\"fees_paid\":\"0\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"College Development Fees\",\"header_id\":\"11\"},{\"fees_paid\":\"0\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\"},{\"fees_paid\":\"0\",\"header\":\"Student Forum fees\",\"header_id\":\"13\"},{\"fees_paid\":\"0\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\"},{\"fees_paid\":\"0\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\"},{\"fees_paid\":\"0\",\"header\":\"Project Fees\",\"header_id\":\"16\"},{\"fees_paid\":\"0\",\"header\":\"University Sports Fees\",\"header_id\":\"17\"},{\"fees_paid\":\"0\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\"},{\"fees_paid\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\"},{\"fees_paid\":\"0\",\"header\":\"Book Bank\",\"header_id\":\"20\"},{\"fees_paid\":\"0\",\"header\":\"Youth Festival\",\"header_id\":\"21\"},{\"fees_paid\":\"0\",\"header\":\"Ashwamedh\",\"header_id\":\"22\"},{\"fees_paid\":\"0\",\"header\":\"Emergency Fees\",\"header_id\":\"23\"},{\"fees_paid\":\"0\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\"},{\"fees_paid\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\"},{\"fees_paid\":\"0\",\"header\":\"Tution Fees\",\"header_id\":\"31\"},{\"fees_paid\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\"},{\"fees_paid\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\"},{\"fees_paid\":\"0\",\"header\":\"Environment Studies Fees\",\"header_id\":\"34\"},{\"fees_paid\":\"0\",\"header\":\"Provisional Passing Certficate Fees\",\"header_id\":\"35\"},{\"fees_paid\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\"},{\"fees_paid\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\"},{\"fees_paid\":\"0\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\"},{\"fees_paid\":\"0\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\"}]},{\"year_id\":\"2\",\"paid_date\":\"05\\/10\\/2021\",\"fees_paid_with_header\":[{\"fees_paid\":\"0\",\"header\":\"Registration Fees\",\"header_id\":\"1\"},{\"fees_paid\":\"0\",\"header\":\"Admission Fees\",\"header_id\":\"2\"},{\"fees_paid\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\"},{\"fees_paid\":\"0\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\"},{\"fees_paid\":\"0\",\"header\":\"Magazine Fees\",\"header_id\":\"5\"},{\"fees_paid\":\"0\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\"},{\"fees_paid\":\"0\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\"},{\"fees_paid\":\"0\",\"header\":\"Gathering Fees\",\"header_id\":\"8\"},{\"fees_paid\":\"0\",\"header\":\"Library Fees\",\"header_id\":\"9\"},{\"fees_paid\":\"0\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"College Development Fees\",\"header_id\":\"11\"},{\"fees_paid\":\"0\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\"},{\"fees_paid\":\"0\",\"header\":\"Student Forum fees\",\"header_id\":\"13\"},{\"fees_paid\":\"0\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\"},{\"fees_paid\":\"0\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\"},{\"fees_paid\":\"0\",\"header\":\"Project Fees\",\"header_id\":\"16\"},{\"fees_paid\":\"0\",\"header\":\"University Sports Fees\",\"header_id\":\"17\"},{\"fees_paid\":\"0\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\"},{\"fees_paid\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\"},{\"fees_paid\":\"0\",\"header\":\"Book Bank\",\"header_id\":\"20\"},{\"fees_paid\":\"0\",\"header\":\"Youth Festival\",\"header_id\":\"21\"},{\"fees_paid\":\"0\",\"header\":\"Ashwamedh\",\"header_id\":\"22\"},{\"fees_paid\":\"0\",\"header\":\"Emergency Fees\",\"header_id\":\"23\"},{\"fees_paid\":\"0\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\"},{\"fees_paid\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\"},{\"fees_paid\":\"1000\",\"header\":\"Tution Fees\",\"header_id\":\"31\"},{\"fees_paid\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\"},{\"fees_paid\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\"},{\"fees_paid\":\"0\",\"header\":\"Environment Studies Fees\",\"header_id\":\"34\"},{\"fees_paid\":\"0\",\"header\":\"Provisional Passing Certficate Fees\",\"header_id\":\"35\"},{\"fees_paid\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\"},{\"fees_paid\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\"},{\"fees_paid\":\"0\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\"},{\"fees_paid\":\"0\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\"}]},{\"year_id\":\"2\",\"paid_date\":\"05\\/10\\/2021\",\"fees_paid_with_header\":[{\"fees_paid\":\"0\",\"header\":\"Registration Fees\",\"header_id\":\"1\"},{\"fees_paid\":\"0\",\"header\":\"Admission Fees\",\"header_id\":\"2\"},{\"fees_paid\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\"},{\"fees_paid\":\"0\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\"},{\"fees_paid\":\"60\",\"header\":\"Magazine Fees\",\"header_id\":\"5\"},{\"fees_paid\":\"10\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\"},{\"fees_paid\":\"50\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\"},{\"fees_paid\":\"60\",\"header\":\"Gathering Fees\",\"header_id\":\"8\"},{\"fees_paid\":\"0\",\"header\":\"Library Fees\",\"header_id\":\"9\"},{\"fees_paid\":\"60\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\"},{\"fees_paid\":\"50\",\"header\":\"College Development Fees\",\"header_id\":\"11\"},{\"fees_paid\":\"9\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\"},{\"fees_paid\":\"15\",\"header\":\"Student Forum fees\",\"header_id\":\"13\"},{\"fees_paid\":\"30\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\"},{\"fees_paid\":\"5\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\"},{\"fees_paid\":\"0\",\"header\":\"Project Fees\",\"header_id\":\"16\"},{\"fees_paid\":\"50\",\"header\":\"University Sports Fees\",\"header_id\":\"17\"},{\"fees_paid\":\"20\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\"},{\"fees_paid\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\"},{\"fees_paid\":\"10\",\"header\":\"Book Bank\",\"header_id\":\"20\"},{\"fees_paid\":\"50\",\"header\":\"Youth Festival\",\"header_id\":\"21\"},{\"fees_paid\":\"30\",\"header\":\"Ashwamedh\",\"header_id\":\"22\"},{\"fees_paid\":\"15\",\"header\":\"Emergency Fees\",\"header_id\":\"23\"},{\"fees_paid\":\"8\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\"},{\"fees_paid\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\"},{\"fees_paid\":\"0\",\"header\":\"Tution Fees\",\"header_id\":\"31\"},{\"fees_paid\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\"},{\"fees_paid\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\"},{\"fees_paid\":\"0\",\"header\":\"Environment Studies Fees\",\"header_id\":\"34\"},{\"fees_paid\":\"0\",\"header\":\"Provisional Passing Certficate Fees\",\"header_id\":\"35\"},{\"fees_paid\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\"},{\"fees_paid\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\"},{\"fees_paid\":\"0\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\"},{\"fees_paid\":\"0\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\"}]},{\"year_id\":\"2\",\"paid_date\":\"05\\/10\\/2021\",\"fees_paid_with_header\":[{\"fees_paid\":\"0\",\"header\":\"Registration Fees\",\"header_id\":\"1\"},{\"fees_paid\":\"0\",\"header\":\"Admission Fees\",\"header_id\":\"2\"},{\"fees_paid\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\"},{\"fees_paid\":\"0\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\"},{\"fees_paid\":\"0\",\"header\":\"Magazine Fees\",\"header_id\":\"5\"},{\"fees_paid\":\"0\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\"},{\"fees_paid\":\"0\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\"},{\"fees_paid\":\"0\",\"header\":\"Gathering Fees\",\"header_id\":\"8\"},{\"fees_paid\":\"0\",\"header\":\"Library Fees\",\"header_id\":\"9\"},{\"fees_paid\":\"0\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"College Development Fees\",\"header_id\":\"11\"},{\"fees_paid\":\"1\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\"},{\"fees_paid\":\"0\",\"header\":\"Student Forum fees\",\"header_id\":\"13\"},{\"fees_paid\":\"0\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\"},{\"fees_paid\":\"0\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\"},{\"fees_paid\":\"0\",\"header\":\"Project Fees\",\"header_id\":\"16\"},{\"fees_paid\":\"0\",\"header\":\"University Sports Fees\",\"header_id\":\"17\"},{\"fees_paid\":\"0\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\"},{\"fees_paid\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\"},{\"fees_paid\":\"0\",\"header\":\"Book Bank\",\"header_id\":\"20\"},{\"fees_paid\":\"0\",\"header\":\"Youth Festival\",\"header_id\":\"21\"},{\"fees_paid\":\"0\",\"header\":\"Ashwamedh\",\"header_id\":\"22\"},{\"fees_paid\":\"0\",\"header\":\"Emergency Fees\",\"header_id\":\"23\"},{\"fees_paid\":\"0\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\"},{\"fees_paid\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\"},{\"fees_paid\":\"0\",\"header\":\"Tution Fees\",\"header_id\":\"31\"},{\"fees_paid\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\"},{\"fees_paid\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\"},{\"fees_paid\":\"0\",\"header\":\"Environment Studies Fees\",\"header_id\":\"34\"},{\"fees_paid\":\"0\",\"header\":\"Provisional Passing Certficate Fees\",\"header_id\":\"35\"},{\"fees_paid\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\"},{\"fees_paid\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\"},{\"fees_paid\":\"0\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\"},{\"fees_paid\":\"0\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\"}]}]'),
(12, 'art 3', 'a', 'a', 'Service', 'a', '0', '0', 'a', '1', 'M', 'a', 'a', '2020-02-02', 'a', 'a', 'HINDU', 'OPEN', 'B+', 'Y', 'Visual_Impairment', '0', 'a', 'a', 'a', '1', '1', '2020-11-11', '1', '1', 11, '2', '1', '2020-02-11', '1', '2', 2, 1, '[{\"year_id\":\"3\",\"current_branch\":\"1\",\"academic_year_id\":\"1\",\"currently\":\"Y\",\"subject\":{\"compulsary\":\"15\",\"secondary\":\"16\",\"optional_subject_1\":\"19\",\"optional_subject_2\":\"20\",\"optional_subject_3\":\"21\",\"optional_subject_4\":\"22\",\"optional_subject_5\":\"23\",\"optional_subject_6\":\"24\",\"optional_subject_7\":\"25\",\"optional_subject_8\":\"25\",\"optional_subject_9\":\"26\"},\"eligible_for_exam\":\"Y\",\"class_name\":\"SY\",\"admission_confirm\":\"Y\",\"admission_date\":\"04-10-2021\",\"maha_dbt_id\":\"\",\"fullfees\":\"SC\",\"fees_deatails\":\"\",\"hostel_requested\":\"Yes\",\"hostel_approved\":\"\",\"hostel_details\":\"\",\"mahadbt_id\":\"\"}]', 0, '2021-10-04 16:56:53', NULL, '', '', 0, 0, 0, 'a', 'a', 1, '0', 'SC', '1', '2', 'UNMARRIED', 'GOVT_OF_INDIA_POST_MATRIC_SCHOLARSHIP', 'a', 'aa', 'EMPLOYED', 'YES', 'YES', 'original', 'original', 'original', 'attested', 'attested', 'attested', 'attested', 'attested', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 1, 'a', 'a', 'a', 'a', 'a', 'a', 'Yes', 'Yes', 'YES', 'YES', NULL),
(13, 'sci 1', 'a', 'a', 'Service', 'a', '0', '0', 'a', '1', 'M', 'a', 'a', '2020-02-02', 'a', 'a', 'HINDU', 'OPEN', 'B+', 'Y', 'Visual_Impairment', '0', 'a', 'a', 'a', '1', '1', '2020-11-11', '1', '1', 11, '2', '1', '2020-02-11', '1', '2', 2, 1, '[{\"year_id\":\"1\",\"current_branch\":\"2\",\"academic_year_id\":\"1\",\"currently\":\"Y\",\"subject\":{\"compulsary\":\"15\",\"secondary\":\"16\",\"optional_subject_1\":\"19\",\"optional_subject_2\":\"20\",\"optional_subject_3\":\"21\",\"optional_subject_4\":\"22\",\"optional_subject_5\":\"23\",\"optional_subject_6\":\"24\",\"optional_subject_7\":\"25\",\"optional_subject_8\":\"25\",\"optional_subject_9\":\"26\"},\"eligible_for_exam\":\"Y\",\"class_name\":\"SY\",\"admission_confirm\":\"Y\",\"admission_date\":\"04-10-2021\",\"maha_dbt_id\":\"\",\"fullfees\":\"SC\",\"fees_deatails\":\"\",\"hostel_requested\":\"Yes\",\"hostel_approved\":\"\",\"hostel_details\":\"\",\"mahadbt_id\":\"\"}]', 0, '2021-10-04 16:56:53', NULL, '', '', 0, 0, 0, 'a', 'a', 1, '0', 'SC', '1', '2', 'UNMARRIED', 'GOVT_OF_INDIA_POST_MATRIC_SCHOLARSHIP', 'a', 'aa', 'EMPLOYED', 'YES', 'YES', 'original', 'original', 'original', 'attested', 'attested', 'attested', 'attested', 'attested', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 1, 'a', 'a', 'a', 'a', 'a', 'a', 'Yes', 'Yes', 'YES', 'YES', '[{\"year_id\":\"1\",\"paid_date\":\"06\\/10\\/2021\",\"fees_paid_with_header\":[{\"fees_paid\":\"10\",\"header\":\"Registration Fees\",\"header_id\":\"1\",\"fees_amount\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"Admission Fees\",\"header_id\":\"2\",\"fees_amount\":\"40\"},{\"fees_paid\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Magazine Fees\",\"header_id\":\"5\",\"fees_amount\":\"60\"},{\"fees_paid\":\"0\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\",\"fees_amount\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\",\"fees_amount\":\"50\"},{\"fees_paid\":\"0\",\"header\":\"Gathering Fees\",\"header_id\":\"8\",\"fees_amount\":\"60\"},{\"fees_paid\":\"0\",\"header\":\"Library Fees\",\"header_id\":\"9\",\"fees_amount\":\"150\"},{\"fees_paid\":\"0\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\",\"fees_amount\":\"60\"},{\"fees_paid\":\"0\",\"header\":\"College Development Fees\",\"header_id\":\"11\",\"fees_amount\":\"50\"},{\"fees_paid\":\"0\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\",\"fees_amount\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"Student Forum fees\",\"header_id\":\"13\",\"fees_amount\":\"15\"},{\"fees_paid\":\"0\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\",\"fees_amount\":\"30\"},{\"fees_paid\":\"0\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\",\"fees_amount\":\"5\"},{\"fees_paid\":\"0\",\"header\":\"Project Fees\",\"header_id\":\"16\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"University Sports Fees\",\"header_id\":\"17\",\"fees_amount\":\"50\"},{\"fees_paid\":\"0\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\",\"fees_amount\":\"20\"},{\"fees_paid\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Book Bank\",\"header_id\":\"20\",\"fees_amount\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"Youth Festival\",\"header_id\":\"21\",\"fees_amount\":\"50\"},{\"fees_paid\":\"0\",\"header\":\"Ashwamedh\",\"header_id\":\"22\",\"fees_amount\":\"30\"},{\"fees_paid\":\"0\",\"header\":\"Emergency Fees\",\"header_id\":\"23\",\"fees_amount\":\"15\"},{\"fees_paid\":\"0\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\",\"fees_amount\":\"8\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\",\"fees_amount\":\"110\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Tution Fees\",\"header_id\":\"31\",\"fees_amount\":\"4000\"},{\"fees_paid\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Environment Sci\",\"header_id\":\"34\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Proirianal Passing Certficate Fees\",\"header_id\":\"35\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\",\"fees_amount\":\"32\"},{\"fees_paid\":\"0\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\",\"fees_amount\":\"50\"}]}]'),
(14, 'sci 2', 'a', 'a', 'Service', 'a', '0', '0', 'a', '1', 'M', 'a', 'a', '2020-02-02', 'a', 'a', 'HINDU', 'OPEN', 'B+', 'Y', 'Visual_Impairment', '0', 'a', 'a', 'a', '1', '1', '2020-11-11', '1', '1', 11, '2', '1', '2020-02-11', '1', '2', 2, 1, '[{\"year_id\":\"2\",\"current_branch\":\"2\",\"academic_year_id\":\"1\",\"currently\":\"Y\",\"subject\":{\"compulsary\":\"15\",\"secondary\":\"16\",\"optional_subject_1\":\"19\",\"optional_subject_2\":\"20\",\"optional_subject_3\":\"21\",\"optional_subject_4\":\"22\",\"optional_subject_5\":\"23\",\"optional_subject_6\":\"24\",\"optional_subject_7\":\"25\",\"optional_subject_8\":\"25\",\"optional_subject_9\":\"26\"},\"eligible_for_exam\":\"Y\",\"class_name\":\"SY\",\"admission_confirm\":\"Y\",\"admission_date\":\"04-10-2021\",\"maha_dbt_id\":\"\",\"fullfees\":\"SC\",\"fees_deatails\":\"\",\"hostel_requested\":\"Yes\",\"hostel_approved\":\"\",\"hostel_details\":\"\",\"mahadbt_id\":\"\"}]', 0, '2021-10-04 16:56:53', NULL, '', '', 0, 0, 0, 'a', 'a', 1, '0', 'SC', '1', '2', 'UNMARRIED', 'GOVT_OF_INDIA_POST_MATRIC_SCHOLARSHIP', 'a', 'aa', 'EMPLOYED', 'YES', 'YES', 'original', 'original', 'original', 'attested', 'attested', 'attested', 'attested', 'attested', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 1, 'a', 'a', 'a', 'a', 'a', 'a', 'Yes', 'Yes', 'YES', 'YES', '[{\"year_id\":\"2\",\"paid_date\":\"05\\/10\\/2021\",\"fees_paid_with_header\":[{\"fees_paid\":\"0\",\"header\":\"Registration Fees\",\"header_id\":\"1\",\"fees_amount\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"Admission Fees\",\"header_id\":\"2\",\"fees_amount\":\"40\"},{\"fees_paid\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\",\"fees_amount\":\"0\"},{\"fees_paid\":\"100\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\",\"fees_amount\":\"300\"},{\"fees_paid\":\"0\",\"header\":\"Magazine Fees\",\"header_id\":\"5\",\"fees_amount\":\"60\"},{\"fees_paid\":\"0\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\",\"fees_amount\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\",\"fees_amount\":\"50\"},{\"fees_paid\":\"0\",\"header\":\"Gathering Fees\",\"header_id\":\"8\",\"fees_amount\":\"60\"},{\"fees_paid\":\"0\",\"header\":\"Library Fees\",\"header_id\":\"9\",\"fees_amount\":\"150\"},{\"fees_paid\":\"0\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\",\"fees_amount\":\"60\"},{\"fees_paid\":\"0\",\"header\":\"College Development Fees\",\"header_id\":\"11\",\"fees_amount\":\"50\"},{\"fees_paid\":\"0\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\",\"fees_amount\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"Student Forum fees\",\"header_id\":\"13\",\"fees_amount\":\"15\"},{\"fees_paid\":\"0\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\",\"fees_amount\":\"30\"},{\"fees_paid\":\"0\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\",\"fees_amount\":\"5\"},{\"fees_paid\":\"0\",\"header\":\"Project Fees\",\"header_id\":\"16\",\"fees_amount\":\"\"},{\"fees_paid\":\"0\",\"header\":\"University Sports Fees\",\"header_id\":\"17\",\"fees_amount\":\"50\"},{\"fees_paid\":\"0\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\",\"fees_amount\":\"20\"},{\"fees_paid\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Book Bank\",\"header_id\":\"20\",\"fees_amount\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"Youth Festival\",\"header_id\":\"21\",\"fees_amount\":\"50\"},{\"fees_paid\":\"0\",\"header\":\"Ashwamedh\",\"header_id\":\"22\",\"fees_amount\":\"30\"},{\"fees_paid\":\"0\",\"header\":\"Emergency Fees\",\"header_id\":\"23\",\"fees_amount\":\"15\"},{\"fees_paid\":\"0\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\",\"fees_amount\":\"8\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Tution Fees\",\"header_id\":\"31\",\"fees_amount\":\"4000\"},{\"fees_paid\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Environment Sci\",\"header_id\":\"34\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Proirianal Passing Certficate Fees\",\"header_id\":\"35\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\",\"fees_amount\":\"32\"},{\"fees_paid\":\"0\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\",\"fees_amount\":\"50\"}]}]'),
(15, 'sci 3', 'a', 'a', 'Service', 'a', '0', '0', 'a', '1', 'M', 'a', 'a', '2020-02-02', 'a', 'a', 'HINDU', 'OPEN', 'B+', 'Y', 'Visual_Impairment', '0', 'a', 'a', 'a', '1', '1', '2020-11-11', '1', '1', 11, '2', '1', '2020-02-11', '1', '2', 2, 1, '[{\"year_id\":\"3\",\"current_branch\":\"2\",\"academic_year_id\":\"1\",\"currently\":\"Y\",\"subject\":{\"compulsary\":\"15\",\"secondary\":\"16\",\"optional_subject_1\":\"19\",\"optional_subject_2\":\"20\",\"optional_subject_3\":\"21\",\"optional_subject_4\":\"22\",\"optional_subject_5\":\"23\",\"optional_subject_6\":\"24\",\"optional_subject_7\":\"25\",\"optional_subject_8\":\"25\",\"optional_subject_9\":\"26\"},\"eligible_for_exam\":\"Y\",\"class_name\":\"SY\",\"admission_confirm\":\"Y\",\"admission_date\":\"04-10-2021\",\"maha_dbt_id\":\"\",\"fullfees\":\"SC\",\"fees_deatails\":\"\",\"hostel_requested\":\"Yes\",\"hostel_approved\":\"\",\"hostel_details\":\"\",\"mahadbt_id\":\"\"}]', 0, '2021-10-04 16:56:53', NULL, '', '', 0, 0, 0, 'a', 'a', 1, '0', 'SC', '1', '2', 'UNMARRIED', 'GOVT_OF_INDIA_POST_MATRIC_SCHOLARSHIP', 'a', 'aa', 'EMPLOYED', 'YES', 'YES', 'original', 'original', 'original', 'attested', 'attested', 'attested', 'attested', 'attested', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 1, 'a', 'a', 'a', 'a', 'a', 'a', 'Yes', 'Yes', 'YES', 'YES', NULL),
(16, 'comm 1', 'a', 'a', 'Service', 'a', '0', '0', 'a', '1', 'M', 'a', 'a', '2020-02-02', 'a', 'a', 'HINDU', 'OPEN', 'B+', 'Y', 'Visual_Impairment', '0', 'a', 'a', 'a', '1', '1', '2020-11-11', '1', '1', 11, '2', '1', '2020-02-11', '1', '2', 2, 1, '[{\"year_id\":\"1\",\"current_branch\":\"3\",\"academic_year_id\":\"1\",\"currently\":\"Y\",\"subject\":{\"compulsary\":\"15\",\"secondary\":\"16\",\"optional_subject_1\":\"19\",\"optional_subject_2\":\"20\",\"optional_subject_3\":\"21\",\"optional_subject_4\":\"22\",\"optional_subject_5\":\"23\",\"optional_subject_6\":\"24\",\"optional_subject_7\":\"25\",\"optional_subject_8\":\"25\",\"optional_subject_9\":\"26\"},\"eligible_for_exam\":\"Y\",\"class_name\":\"SY\",\"admission_confirm\":\"Y\",\"admission_date\":\"04-10-2021\",\"maha_dbt_id\":\"\",\"fullfees\":\"SC\",\"fees_deatails\":\"\",\"hostel_requested\":\"Yes\",\"hostel_approved\":\"\",\"hostel_details\":\"\",\"mahadbt_id\":\"\"}]', 0, '2021-10-04 16:56:53', NULL, '', '', 0, 0, 0, 'a', 'a', 1, '0', 'SC', '1', '2', 'UNMARRIED', 'GOVT_OF_INDIA_POST_MATRIC_SCHOLARSHIP', 'a', 'aa', 'EMPLOYED', 'YES', 'YES', 'original', 'original', 'original', 'attested', 'attested', 'attested', 'attested', 'attested', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 1, 'a', 'a', 'a', 'a', 'a', 'a', 'Yes', 'Yes', 'YES', 'YES', NULL),
(17, 'comm 2', 'a', 'a', 'Service', 'a', '0', '0', 'a', '1', 'M', 'a', 'a', '2020-02-02', 'a', 'a', 'HINDU', 'OPEN', 'B+', 'Y', 'Visual_Impairment', '0', 'a', 'a', 'a', '1', '1', '2020-11-11', '1', '1', 11, '2', '1', '2020-02-11', '1', '2', 2, 1, '[{\"year_id\":\"2\",\"current_branch\":\"3\",\"academic_year_id\":\"1\",\"currently\":\"Y\",\"subject\":{\"compulsary\":\"15\",\"secondary\":\"16\",\"optional_subject_1\":\"19\",\"optional_subject_2\":\"20\",\"optional_subject_3\":\"21\",\"optional_subject_4\":\"22\",\"optional_subject_5\":\"23\",\"optional_subject_6\":\"24\",\"optional_subject_7\":\"25\",\"optional_subject_8\":\"25\",\"optional_subject_9\":\"26\"},\"eligible_for_exam\":\"Y\",\"class_name\":\"SY\",\"admission_confirm\":\"Y\",\"admission_date\":\"04-10-2021\",\"maha_dbt_id\":\"\",\"fullfees\":\"SC\",\"fees_deatails\":\"\",\"hostel_requested\":\"Yes\",\"hostel_approved\":\"\",\"hostel_details\":\"\",\"mahadbt_id\":\"\"}]', 0, '2021-10-04 16:56:53', NULL, '', '', 0, 0, 0, 'a', 'a', 1, '0', 'SC', '1', '2', 'UNMARRIED', 'GOVT_OF_INDIA_POST_MATRIC_SCHOLARSHIP', 'a', 'aa', 'EMPLOYED', 'YES', 'YES', 'original', 'original', 'original', 'attested', 'attested', 'attested', 'attested', 'attested', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 1, 'a', 'a', 'a', 'a', 'a', 'a', 'Yes', 'Yes', 'YES', 'YES', NULL),
(18, 'comm 3', 'a', 'a', 'Service', 'a', '0', '0', 'a', '1', 'M', 'a', 'a', '2020-02-02', 'a', 'a', 'HINDU', 'OPEN', 'B+', 'Y', 'Visual_Impairment', '0', 'a', 'a', 'a', '1', '1', '2020-11-11', '1', '1', 11, '2', '1', '2020-02-11', '1', '2', 2, 1, '[{\"year_id\":\"3\",\"current_branch\":\"3\",\"academic_year_id\":\"1\",\"currently\":\"Y\",\"subject\":{\"compulsary\":\"15\",\"secondary\":\"16\",\"optional_subject_1\":\"19\",\"optional_subject_2\":\"20\",\"optional_subject_3\":\"21\",\"optional_subject_4\":\"22\",\"optional_subject_5\":\"23\",\"optional_subject_6\":\"24\",\"optional_subject_7\":\"25\",\"optional_subject_8\":\"25\",\"optional_subject_9\":\"26\"},\"eligible_for_exam\":\"Y\",\"class_name\":\"SY\",\"admission_confirm\":\"Y\",\"admission_date\":\"04-10-2021\",\"maha_dbt_id\":\"\",\"fullfees\":\"SC\",\"fees_deatails\":\"\",\"hostel_requested\":\"Yes\",\"hostel_approved\":\"\",\"hostel_details\":\"\",\"mahadbt_id\":\"\"}]', 0, '2021-10-04 16:56:53', NULL, '', '', 0, 0, 0, 'a', 'a', 1, '0', 'SC', '1', '2', 'UNMARRIED', 'GOVT_OF_INDIA_POST_MATRIC_SCHOLARSHIP', 'a', 'aa', 'EMPLOYED', 'YES', 'YES', 'original', 'original', 'original', 'attested', 'attested', 'attested', 'attested', 'attested', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 1, 'a', 'a', 'a', 'a', 'a', 'a', 'Yes', 'Yes', 'YES', 'YES', NULL);
INSERT INTO `student` (`student_id`, `student_full_name`, `father_full_name`, `mother_full_name`, `guardian_occupation`, `family_income`, `student_mobile_no`, `landline`, `student_personal_email_id`, `guardian_mobile_no`, `gender`, `mother_tongue`, `birth_place`, `date_of_birth`, `caste`, `sub_caste`, `religion`, `caste_category`, `blood_group`, `physically_handicapped`, `handicap_type`, `student_aadhar_no`, `domicile_state`, `permanent_country`, `permanent_pin`, `ssc_seat_no`, `ssc_board_name`, `ssc_pass_date`, `ssc_school_college_name`, `ssc_passing_cert_no`, `ssc_out_of`, `hsc_seat_no`, `hsc_board_name`, `hsc_pass_date`, `hsc_school_college_name`, `hsc_passing_cert_no`, `hsc_out_of`, `is_active`, `academics`, `is_deleted`, `created_on`, `on_update`, `student_image`, `student_signature`, `ID_card_request`, `ID_card_given`, `login_status`, `div`, `admissionno`, `branche_id`, `idcard_reject`, `concession_fees`, `ssc_total_marks`, `hsc_total_marks`, `marital_status`, `social_reservation`, `guardian_name`, `guardian_relation`, `employment_status`, `ncc_nss`, `hostel`, `ssc_cert`, `hsc_cert`, `leaving_cert`, `attested_caste_cert`, `attested_non_creamy`, `affidavit_marriage_gazette`, `domicile_cert`, `phy_challenge_cert`, `registration_form_cert`, `admission_form_cert`, `eligibility_cert`, `incorme_cert`, `migration_cert`, `date_cert`, `ebc_ptc_ff_gf_btc_cert`, `gap_cert`, `other_cert`, `course_id`, `eligibility_no`, `permanent_address`, `correspondence_address`, `last_college`, `last_college_year`, `last_college_roll`, `hsc_done`, `ssc_done`, `markmemo_given`, `is_gap`, `fees_installments`) VALUES
(19, 'BSC SY', 'a', 'a', 'Service', 'a', '0', '0', 'a', '1', 'M', 'a', 'a', '2020-02-02', 'a', 'a', 'HINDU', 'OPEN', 'B+', 'Y', 'Visual_Impairment', '0', 'a', 'a', 'a', '1', '1', '2020-11-11', '1', '1', 11, '2', '1', '2020-02-11', '1', '2', 2, 1, '[{\"year_id\":\"2\",\"current_branch\":\"2\",\"academic_year_id\":\"1\",\"currently\":\"Y\",\"subject\":{\"compulsary\":\"15\",\"secondary\":\"16\",\"optional_subject_1\":\"19\",\"optional_subject_2\":\"20\",\"optional_subject_3\":\"21\",\"optional_subject_4\":\"22\",\"optional_subject_5\":\"23\",\"optional_subject_6\":\"24\",\"optional_subject_7\":\"25\",\"optional_subject_8\":\"25\",\"optional_subject_9\":\"26\"},\"eligible_for_exam\":\"Y\",\"class_name\":\"SY\",\"admission_confirm\":\"Y\",\"admission_date\":\"04-10-2021\",\"maha_dbt_id\":\"\",\"fullfees\":\"SC\",\"fees_deatails\":\"\",\"hostel_requested\":\"Yes\",\"hostel_approved\":\"\",\"hostel_details\":\"\",\"mahadbt_id\":\"\"}]', 0, '2021-10-04 16:56:53', NULL, '', '', 0, 0, 0, 'a', 'a', 1, '0', 'SC', '1', '2', 'UNMARRIED', 'GOVT_OF_INDIA_POST_MATRIC_SCHOLARSHIP', 'a', 'aa', 'EMPLOYED', 'YES', 'YES', 'original', 'original', 'original', 'attested', 'attested', 'attested', 'attested', 'attested', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 'original', 1, 'a', 'a', 'a', 'a', 'a', 'a', 'Yes', 'Yes', 'YES', 'YES', '[{\"year_id\":\"2\",\"paid_date\":\"05\\/10\\/2021\",\"fees_paid_with_header\":[{\"fees_paid\":\"0\",\"header\":\"Registration Fees\",\"header_id\":\"1\",\"fees_amount\":\"10\"},{\"fees_paid\":\"20\",\"header\":\"Admission Fees\",\"header_id\":\"2\",\"fees_amount\":\"40\"},{\"fees_paid\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\",\"fees_amount\":\"300\"},{\"fees_paid\":\"0\",\"header\":\"Magazine Fees\",\"header_id\":\"5\",\"fees_amount\":\"60\"},{\"fees_paid\":\"0\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\",\"fees_amount\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\",\"fees_amount\":\"50\"},{\"fees_paid\":\"0\",\"header\":\"Gathering Fees\",\"header_id\":\"8\",\"fees_amount\":\"60\"},{\"fees_paid\":\"0\",\"header\":\"Library Fees\",\"header_id\":\"9\",\"fees_amount\":\"150\"},{\"fees_paid\":\"0\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\",\"fees_amount\":\"60\"},{\"fees_paid\":\"0\",\"header\":\"College Development Fees\",\"header_id\":\"11\",\"fees_amount\":\"50\"},{\"fees_paid\":\"0\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\",\"fees_amount\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"Student Forum fees\",\"header_id\":\"13\",\"fees_amount\":\"15\"},{\"fees_paid\":\"0\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\",\"fees_amount\":\"30\"},{\"fees_paid\":\"0\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\",\"fees_amount\":\"5\"},{\"fees_paid\":\"0\",\"header\":\"Project Fees\",\"header_id\":\"16\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"University Sports Fees\",\"header_id\":\"17\",\"fees_amount\":\"50\"},{\"fees_paid\":\"0\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\",\"fees_amount\":\"20\"},{\"fees_paid\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Book Bank\",\"header_id\":\"20\",\"fees_amount\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"Youth Festival\",\"header_id\":\"21\",\"fees_amount\":\"50\"},{\"fees_paid\":\"0\",\"header\":\"Ashwamedh\",\"header_id\":\"22\",\"fees_amount\":\"30\"},{\"fees_paid\":\"0\",\"header\":\"Emergency Fees\",\"header_id\":\"23\",\"fees_amount\":\"15\"},{\"fees_paid\":\"0\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\",\"fees_amount\":\"8\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Tution Fees\",\"header_id\":\"31\",\"fees_amount\":\"4000\"},{\"fees_paid\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Environment Sci\",\"header_id\":\"34\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Proirianal Passing Certficate Fees\",\"header_id\":\"35\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\",\"fees_amount\":\"0\"},{\"fees_paid\":\"0\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\",\"fees_amount\":\"32\"},{\"fees_paid\":\"0\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\",\"fees_amount\":\"50\"}]},{\"year_id\":\"2\",\"paid_date\":\"05\\/10\\/2021\",\"fees_paid_with_header\":[{\"fees_paid\":\"0\",\"header\":\"Registration Fees\",\"header_id\":\"1\"},{\"fees_paid\":\"0\",\"header\":\"Admission Fees\",\"header_id\":\"2\"},{\"fees_paid\":\"0\",\"header\":\"Library Deposit\",\"header_id\":\"3\"},{\"fees_paid\":\"0\",\"header\":\"Laboratory Fees\",\"header_id\":\"4\"},{\"fees_paid\":\"0\",\"header\":\"Magazine Fees\",\"header_id\":\"5\"},{\"fees_paid\":\"0\",\"header\":\"S.A.F. Fees\",\"header_id\":\"6\"},{\"fees_paid\":\"0\",\"header\":\"Games Fees(Gymkhana)\",\"header_id\":\"7\"},{\"fees_paid\":\"0\",\"header\":\"Gathering Fees\",\"header_id\":\"8\"},{\"fees_paid\":\"0\",\"header\":\"Library Fees\",\"header_id\":\"9\"},{\"fees_paid\":\"0\",\"header\":\"Student Well Fare Fees\",\"header_id\":\"10\"},{\"fees_paid\":\"0\",\"header\":\"College Development Fees\",\"header_id\":\"11\"},{\"fees_paid\":\"0\",\"header\":\"Identity Card Fees\",\"header_id\":\"12\"},{\"fees_paid\":\"0\",\"header\":\"Student Forum fees\",\"header_id\":\"13\"},{\"fees_paid\":\"0\",\"header\":\"Home Exam Fees\",\"header_id\":\"14\"},{\"fees_paid\":\"0\",\"header\":\"Medical Examination Fees\",\"header_id\":\"15\"},{\"fees_paid\":\"0\",\"header\":\"Project Fees\",\"header_id\":\"16\"},{\"fees_paid\":\"0\",\"header\":\"University Sports Fees\",\"header_id\":\"17\"},{\"fees_paid\":\"0\",\"header\":\"Miscellaneous Fees(Other fees)\",\"header_id\":\"18\"},{\"fees_paid\":\"0\",\"header\":\"T.C. Fees\",\"header_id\":\"19\"},{\"fees_paid\":\"0\",\"header\":\"Book Bank\",\"header_id\":\"20\"},{\"fees_paid\":\"0\",\"header\":\"Youth Festival\",\"header_id\":\"21\"},{\"fees_paid\":\"0\",\"header\":\"Ashwamedh\",\"header_id\":\"22\"},{\"fees_paid\":\"0\",\"header\":\"Emergency Fees\",\"header_id\":\"23\"},{\"fees_paid\":\"0\",\"header\":\"Students Insurance Fees\",\"header_id\":\"24\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Form\",\"header_id\":\"25\"},{\"fees_paid\":\"0\",\"header\":\"Eligibility Fees\",\"header_id\":\"26\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Form\",\"header_id\":\"27\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Fees\",\"header_id\":\"28\"},{\"fees_paid\":\"0\",\"header\":\"Practical Fees\",\"header_id\":\"29\"},{\"fees_paid\":\"0\",\"header\":\"University Exam Late Fees\",\"header_id\":\"30\"},{\"fees_paid\":\"3500\",\"header\":\"Tution Fees\",\"header_id\":\"31\"},{\"fees_paid\":\"0\",\"header\":\"Verification at A.B.\",\"header_id\":\"32\"},{\"fees_paid\":\"0\",\"header\":\"Fine Fees\",\"header_id\":\"33\"},{\"fees_paid\":\"0\",\"header\":\"Environment Sci\",\"header_id\":\"34\"},{\"fees_paid\":\"0\",\"header\":\"Proirianal Passing Certficate Fees\",\"header_id\":\"35\"},{\"fees_paid\":\"0\",\"header\":\"Library Non.Recurring\",\"header_id\":\"36\"},{\"fees_paid\":\"0\",\"header\":\"E Suvidha\",\"header_id\":\"37\"},{\"fees_paid\":\"0\",\"header\":\"Chancellor\'s Office Activities Fees\",\"header_id\":\"38\"},{\"fees_paid\":\"0\",\"header\":\"Zonal Sports Council Fees\",\"header_id\":\"39\"}]}]'),
(20, 'a', 'a', 'a', 'Service', 'a', '0', '0', 'a', '2', 'M', 'a', 'a', '1000-01-01', 'a', 'a', 'MUSLIM', 'SC', 'A+', 'Y', 'Visual_Impairment', '0', 'a', 'a', 'a', '1', 'a', '1111-01-01', 'a', '1', 1, '1', '1', '1111-01-01', '1', '1', 1, 1, '[{\"year_id\":\"1\",\"current_branch\":\"1\",\"academic_year_id\":\"1\",\"currently\":\"Y\",\"subject\":{\"compulsary\":\"1\",\"secondary\":\"3\",\"optional_subject_1\":\"5\",\"optional_subject_2\":\"6\",\"optional_subject_3\":\"7\",\"optional_subject_4\":\"8\",\"optional_subject_5\":\"11\",\"optional_subject_6\":\"13\",\"optional_subject_7\":\"12\",\"optional_subject_8\":\"14\",\"optional_subject_9\":\"\"},\"eligible_for_exam\":\"Y\",\"class_name\":\"\",\"admission_confirm\":\"Y\",\"admission_date\":false,\"maha_dbt_id\":\"\",\"fullfees\":\"NT\",\"fees_deatails\":\"\",\"hostel_requested\":\"NO\",\"hostel_approved\":\"\",\"hostel_details\":\"\",\"mahadbt_id\":\"\"}]', 0, '2021-10-05 18:03:09', NULL, '', '', 0, 0, 0, 'a', 'a', 1, '0', 'NT', '1', '1', 'UNMARRIED', 'RAJASHRI_CHHATRAPATI_SHAHU_MAHARAJ_MERIT_SCHOLARSHIP', 'a', 'a', 'EMPLOYED', 'YES', 'NO', 'original', 'original', 'original', 'attested', 'attested', 'attested', 'attested', 'attested', 'no', '', '', '', '', '', '', '', '', 1, 'a', 'a', 'a', 'a', 'a', 'a', 'No', 'Yes', 'YES', 'YES', NULL),
(21, '1', '1', '1', 'Service', '1', '1', '1', 'uttkarshkabde81@gmaill.com', '1', 'F', '1', '1', '2021-12-12', '1', '1', 'HINDU', 'OPEN', 'A+', 'N', '', '1', '1', '1', '1', '1', '1', '2021-12-11', '1', '1', 1, '1', '1', '2021-12-11', '1', '1', 1, 1, '[{\"year_id\":\"1\",\"current_branch\":\"1\",\"academic_year_id\":\"1\",\"currently\":\"Y\",\"subject\":{\"compulsary\":\"1\",\"secondary\":\"2\",\"optional_subject_1\":\"6\",\"optional_subject_2\":\"6\",\"optional_subject_3\":\"6\",\"optional_subject_4\":\"6\",\"optional_subject_5\":\"6\",\"optional_subject_6\":\"6\",\"optional_subject_7\":\"6\",\"optional_subject_8\":\"6\",\"optional_subject_9\":\"6\"},\"eligible_for_exam\":\"Y\",\"class_name\":\"\",\"admission_confirm\":\"Y\",\"admission_date\":false,\"maha_dbt_id\":\"\",\"fullfees\":\"EBC\",\"fees_deatails\":\"\",\"hostel_requested\":\"YES\",\"hostel_approved\":\"\",\"hostel_details\":\"\",\"mahadbt_id\":\"\"}]', 0, '2021-10-06 16:20:05', NULL, '1633519188.png', NULL, 0, 0, 0, '1', '1', 1, '0', 'EBC', '1', '1', 'UNMARRIED', 'GOVT_OF_INDIA_POST_MATRIC_SCHOLARSHIP', '1', '1', 'EMPLOYED', 'YES', 'YES', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 1, '1', '1', '1', '1', '1', '1', 'No', 'No', 'YES', 'YES', NULL),
(22, '1', '1', '1', 'Business', 'ss', '1', '1', '1', '1', 'F', '1', '1', '1010-10-01', '1', '1', 'HINDU', 'OPEN', 'A+', 'N', '', '1', '1', '1', '1', '1', '1', '0011-01-11', '1', '1', 1, '1', '1', '1010-10-01', '1', '1', 1, 1, '[{\"year_id\":\"1\",\"current_branch\":\"1\",\"academic_year_id\":\"1\",\"currently\":\"Y\",\"subject\":{\"compulsary\":\"1\",\"secondary\":\"4\",\"optional_subject_1\":\"5\",\"optional_subject_2\":\"9\",\"optional_subject_3\":\"12\",\"optional_subject_4\":\"14\",\"optional_subject_5\":\"\",\"optional_subject_6\":\"\",\"optional_subject_7\":\"\",\"optional_subject_8\":\"\",\"optional_subject_9\":\"\"},\"eligible_for_exam\":\"Y\",\"class_name\":\"\",\"admission_confirm\":\"Y\",\"admission_date\":false,\"maha_dbt_id\":\"\",\"fullfees\":\"EBC\",\"fees_deatails\":\"\",\"hostel_requested\":\"NO\",\"hostel_approved\":\"\",\"hostel_details\":\"\",\"mahadbt_id\":\"\"}]', 0, '2021-10-06 16:55:42', NULL, '1633519467.png', NULL, 0, 0, 0, '1', '1', 1, '0', 'EBC', '1', '1', 'UNMARRIED', 'GOVT_OF_INDIA_POST_MATRIC_SCHOLARSHIP', '1', '1', 'UNEMPLOYED', 'NO', 'NO', 'original', 'original', 'attested', 'attested', 'attested', 'attested', 'attested', 'attested', 'original', 'original', 'original', '', '', '', '', '', '', 1, '1', '1', '1', '1', '1', '1', 'No', 'No', 'YES', 'YES', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `subject_id` int(10) NOT NULL,
  `course_id` int(10) NOT NULL,
  `branch_id` int(10) NOT NULL,
  `year_id` int(10) NOT NULL,
  `subject_name` varchar(150) NOT NULL,
  `subject_short_name` varchar(10) DEFAULT NULL,
  `is_compulsary` enum('Y','N') NOT NULL,
  `is_secondary` enum('Y','N') NOT NULL,
  `is_optional` enum('Y','N') NOT NULL,
  `is_active` int(2) NOT NULL DEFAULT '1',
  `is_deleted` int(2) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`subject_id`, `course_id`, `branch_id`, `year_id`, `subject_name`, `subject_short_name`, `is_compulsary`, `is_secondary`, `is_optional`, `is_active`, `is_deleted`) VALUES
(1, 1, 1, 1, 'English', 'Eng', 'Y', 'N', 'N', 1, 0),
(2, 1, 1, 1, 'Marathi', 'Mar', 'N', 'Y', 'N', 1, 0),
(3, 1, 1, 1, 'Hindi', 'Hin', 'N', 'Y', 'N', 1, 0),
(4, 1, 1, 1, 'Urdu', 'Urd', 'N', 'Y', 'N', 1, 0),
(5, 1, 1, 1, 'History', 'His', 'N', 'N', 'Y', 1, 0),
(6, 1, 1, 1, 'Sociology', 'Soc', 'N', 'N', 'Y', 1, 0),
(7, 1, 1, 1, 'Economics', 'Eco', 'N', 'N', 'Y', 1, 0),
(8, 1, 1, 1, 'Home Science', 'HS', 'N', 'N', 'Y', 1, 0),
(9, 1, 1, 1, 'Marathi', 'Mar', 'N', 'N', 'Y', 1, 0),
(10, 1, 1, 1, 'Hindi', 'Hin', 'N', 'N', 'Y', 1, 0),
(11, 1, 1, 1, 'Urdu', 'Urd', 'N', 'N', 'Y', 1, 0),
(12, 1, 1, 1, 'Political Science', 'PS', 'N', 'N', 'Y', 1, 0),
(13, 1, 1, 1, 'English', 'Eng', 'N', 'N', 'Y', 1, 0),
(14, 1, 1, 1, 'Sanskrit', 'Sns', 'N', 'N', 'Y', 1, 0),
(15, 1, 1, 2, 'English', 'Eng', 'Y', 'N', 'N', 1, 0),
(16, 1, 1, 2, 'Marathi', 'Mar', 'N', 'Y', 'N', 1, 0),
(17, 1, 1, 2, 'Hindi', 'Hin', 'N', 'Y', 'N', 1, 0),
(18, 1, 1, 2, 'Urdu', 'Urd', 'N', 'Y', 'N', 1, 0),
(19, 1, 1, 2, 'History', 'His', 'N', 'N', 'Y', 1, 0),
(20, 1, 1, 2, 'Sociology', 'Soc', 'N', 'N', 'Y', 1, 0),
(21, 1, 1, 2, 'Economics', 'Eco', 'N', 'N', 'Y', 1, 0),
(22, 1, 1, 2, 'Home Science', 'HS', 'N', 'N', 'Y', 1, 0),
(23, 1, 1, 2, 'Marathi', 'Mar', 'N', 'N', 'Y', 1, 0),
(24, 1, 1, 2, 'Hindi', 'Hin', 'N', 'N', 'Y', 1, 0),
(25, 1, 1, 2, 'Urdu', 'Urd', 'N', 'N', 'Y', 1, 0),
(26, 1, 1, 2, 'Political Science', 'PS', 'N', 'N', 'Y', 1, 0),
(27, 1, 1, 2, 'English', 'Eng', 'N', 'N', 'Y', 1, 0),
(28, 1, 1, 2, 'Sanskrit', 'Sns', 'N', 'N', 'Y', 1, 0),
(33, 1, 1, 3, 'History', 'His', 'N', 'N', 'Y', 1, 0),
(34, 1, 1, 3, 'Sociology', 'Soc', 'N', 'N', 'Y', 1, 0),
(35, 1, 1, 3, 'Economics', 'Eco', 'N', 'N', 'Y', 1, 0),
(36, 1, 1, 3, 'Home Science', 'HS', 'N', 'N', 'Y', 1, 0),
(37, 1, 1, 3, 'Marathi', 'Mar', 'N', 'N', 'Y', 1, 0),
(38, 1, 1, 3, 'Hindi', 'Hin', 'N', 'N', 'Y', 1, 0),
(39, 1, 1, 3, 'Urdu', 'Urd', 'N', 'N', 'Y', 1, 0),
(40, 1, 1, 3, 'Political Science', 'PS', 'N', 'N', 'Y', 1, 0),
(41, 1, 1, 3, 'English', 'Eng', 'N', 'N', 'Y', 1, 0),
(42, 1, 1, 3, 'Sanskrit', 'Sns', 'N', 'N', 'Y', 1, 0),
(43, 1, 3, 1, 'English', 'Eng', 'Y', 'N', 'N', 1, 0),
(44, 1, 3, 1, 'Marathi', 'Mar', 'N', 'Y', 'N', 1, 0),
(45, 1, 3, 1, 'Hindi', 'Hin', 'N', 'Y', 'N', 1, 0),
(46, 1, 3, 1, 'Urdu', 'Urd', 'N', 'Y', 'N', 1, 0),
(47, 1, 3, 1, 'Fundamentals of Financial Accounting', 'FFA', 'N', 'N', 'Y', 1, 0),
(48, 1, 3, 1, 'Business Statistics', 'BS', 'N', 'N', 'Y', 1, 0),
(49, 1, 3, 1, 'Business Economics', 'BE', 'N', 'N', 'Y', 1, 0),
(50, 1, 3, 1, 'Fundamentals of Business Communication', 'FBC', 'N', 'N', 'Y', 1, 0),
(51, 1, 3, 1, 'Business Law', 'BL', 'N', 'N', 'Y', 1, 0),
(52, 1, 3, 2, 'English', 'Eng', 'Y', 'N', 'N', 1, 0),
(53, 1, 3, 2, 'Marathi', 'Mar', 'N', 'Y', 'N', 1, 0),
(54, 1, 3, 2, 'Hindi', 'Hin', 'N', 'Y', 'N', 1, 0),
(55, 1, 3, 2, 'Urdu', 'Urd', 'N', 'Y', 'N', 1, 0),
(56, 1, 3, 2, 'Corporate Accounting', 'COA', 'N', 'N', 'Y', 1, 0),
(57, 1, 3, 2, 'Cost Accounting', 'CA', 'N', 'N', 'Y', 1, 0),
(58, 1, 3, 2, 'Principles of Business Management', 'PBM', 'N', 'N', 'Y', 1, 0),
(59, 1, 3, 2, 'Mercantile Law', 'ML', 'N', 'N', 'Y', 1, 0),
(60, 1, 3, 2, 'Fundamentals of Income Tax', 'FIT', 'N', 'N', 'Y', 1, 0),
(61, 1, 3, 2, 'E-Commerce', 'ECOM', 'N', 'N', 'Y', 1, 0),
(63, 1, 3, 3, 'Advance Accounting', 'AA', 'N', 'N', 'Y', 1, 0),
(64, 1, 3, 3, 'Management Accounting', 'MA', 'N', 'N', 'Y', 1, 0),
(65, 1, 3, 3, 'Auditing', 'AUD', 'N', 'N', 'Y', 1, 0),
(66, 1, 3, 3, 'Human Resource Management', 'HRM', 'N', 'N', 'Y', 1, 0),
(67, 1, 3, 3, 'Indian Economy', 'IE', 'N', 'N', 'Y', 1, 0),
(68, 1, 3, 3, 'Training & Field Work', 'T&FW', 'N', 'N', 'Y', 1, 0),
(70, 1, 3, 3, 'Environment Studies', 'BME', 'N', 'N', 'Y', 1, 0),
(71, 1, 3, 3, 'Self Employment', 'SE', 'N', 'N', 'Y', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `years`
--

CREATE TABLE `years` (
  `years_id` int(11) NOT NULL,
  `year_name` varchar(50) DEFAULT NULL,
  `is_active` tinyint(10) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(10) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `on_update` timestamp NULL DEFAULT NULL,
  `year_short_name` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `years`
--

INSERT INTO `years` (`years_id`, `year_name`, `is_active`, `is_deleted`, `created_on`, `on_update`, `year_short_name`) VALUES
(1, 'First Year', 1, 0, '2021-03-08 13:09:24', NULL, 'FY'),
(2, 'Second Year', 1, 0, '2021-03-08 13:09:24', NULL, 'SY'),
(3, 'Third Year', 1, 0, '2021-03-08 13:09:24', NULL, 'TY');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `academic_year`
--
ALTER TABLE `academic_year`
  ADD PRIMARY KEY (`academic_year_id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `bonafied_certificate`
--
ALTER TABLE `bonafied_certificate`
  ADD PRIMARY KEY (`bonafied_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`branches_id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `branch_and_year`
--
ALTER TABLE `branch_and_year`
  ADD PRIMARY KEY (`branch_and_year_id`),
  ADD KEY `branch_id` (`branch_id`),
  ADD KEY `year_id` (`year_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`courses_id`);

--
-- Indexes for table `employee_position`
--
ALTER TABLE `employee_position`
  ADD PRIMARY KEY (`employee_position_id`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`faculty_id`);

--
-- Indexes for table `fees_element`
--
ALTER TABLE `fees_element`
  ADD PRIMARY KEY (`fees_element_id`);

--
-- Indexes for table `general_settings`
--
ALTER TABLE `general_settings`
  ADD PRIMARY KEY (`general_settings_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`),
  ADD KEY `branche_id` (`branche_id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`subject_id`),
  ADD KEY `branch_id` (`branch_id`),
  ADD KEY `course_id` (`course_id`),
  ADD KEY `year_id` (`year_id`);

--
-- Indexes for table `years`
--
ALTER TABLE `years`
  ADD PRIMARY KEY (`years_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `academic_year`
--
ALTER TABLE `academic_year`
  MODIFY `academic_year_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `bonafied_certificate`
--
ALTER TABLE `bonafied_certificate`
  MODIFY `bonafied_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `branches`
--
ALTER TABLE `branches`
  MODIFY `branches_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `branch_and_year`
--
ALTER TABLE `branch_and_year`
  MODIFY `branch_and_year_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `courses_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `employee_position`
--
ALTER TABLE `employee_position`
  MODIFY `employee_position_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;
--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `faculty_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `fees_element`
--
ALTER TABLE `fees_element`
  MODIFY `fees_element_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT for table `general_settings`
--
ALTER TABLE `general_settings`
  MODIFY `general_settings_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `subject_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;
--
-- AUTO_INCREMENT for table `years`
--
ALTER TABLE `years`
  MODIFY `years_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `bonafied_certificate`
--
ALTER TABLE `bonafied_certificate`
  ADD CONSTRAINT `bonafied_certificate_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `student` (`student_id`);

--
-- Constraints for table `branches`
--
ALTER TABLE `branches`
  ADD CONSTRAINT `branches_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`courses_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `branch_and_year`
--
ALTER TABLE `branch_and_year`
  ADD CONSTRAINT `branch_and_year_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branches_id`),
  ADD CONSTRAINT `branch_and_year_ibfk_2` FOREIGN KEY (`year_id`) REFERENCES `years` (`years_id`);

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`courses_id`),
  ADD CONSTRAINT `student_ibfk_2` FOREIGN KEY (`branche_id`) REFERENCES `branches` (`branches_id`);

--
-- Constraints for table `subjects`
--
ALTER TABLE `subjects`
  ADD CONSTRAINT `subjects_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branches_id`),
  ADD CONSTRAINT `subjects_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`courses_id`),
  ADD CONSTRAINT `subjects_ibfk_3` FOREIGN KEY (`year_id`) REFERENCES `years` (`years_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
